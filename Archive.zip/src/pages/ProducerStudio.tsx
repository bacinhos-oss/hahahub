import React, { useState, useEffect } from 'react';
import { User, Show } from '../types';
import { supabase } from '../lib/supabase';

interface ProducerStudioProps {
  user: User;
  shows: Show[];
  initialTab?: StudioTab;
  hideHeader?: boolean;
  hideTabs?: boolean;
}

type StudioTab = 'dashboard' | 'royalty' | 'incoming' | 'contracts' | 'calculator' | 'contacts' | 'log';

const STORAGE_KEY = 'hahahub_studio_';

function load(key: string) {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY + key) || '[]'); } catch { return []; }
}
function save(key: string, data: any) {
  localStorage.setItem(STORAGE_KEY + key, JSON.stringify(data));
}

// ── CONTRACT EDITOR — defined outside to prevent re-mount on parent render ──
const ContractEditor: React.FC<{
  c: any;
  initialText: string;
  onSave: (id: string, text: string) => void;
  onClose: () => void;
}> = ({ c, initialText, onSave, onClose }) => {
  const [localText, setLocalText] = React.useState(initialText);
  return (
    <div className="border-t-4 border-brand-yellow/30 p-4 space-y-3 bg-black/20">
      <p className="text-[9px] font-black uppercase italic text-brand-yellow tracking-widest">Edit Contract</p>
      <textarea value={localText} onChange={e => setLocalText(e.target.value)} rows={16}
        className="w-full bg-brand-black border-2 border-brand-yellow/30 focus:border-brand-yellow p-4 text-white/80 font-mono text-xs outline-none resize-y leading-relaxed" />
      <div className="flex gap-2 flex-wrap">
        <button onClick={() => onSave(c.id, localText)}
          className="bg-brand-yellow text-black px-4 py-2 font-black uppercase italic text-xs border-2 border-black hover:bg-white transition-all">💾 Save</button>
        <button onClick={() => { if (window.confirm('Restore last saved version?')) setLocalText(c.body || ''); }}
          className="border-2 border-white/20 text-white/30 px-4 py-2 font-black uppercase italic text-xs hover:border-brand-pink hover:text-brand-pink transition-all">↩ Restore</button>
        <button onClick={() => { const blob = new Blob([localText], { type: 'text/plain' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = (c.title || 'contract').replace(/\s+/g, '_') + '.txt'; a.click(); }}
          className="border-2 border-brand-cyan/40 text-brand-cyan px-4 py-2 font-black uppercase italic text-xs hover:bg-brand-cyan hover:text-black transition-all">📥 .txt</button>
        <button onClick={() => { const w = window.open('', '_blank'); if (w) { w.document.write(`<html><head><style>body{font-family:monospace;padding:40px;font-size:13px;line-height:1.8;}</style></head><body><pre>${localText}</pre></body></html>`); w.document.close(); w.print(); } }}
          className="border-2 border-white/20 text-white/30 px-4 py-2 font-black uppercase italic text-xs hover:text-white transition-all">🖨️ Print</button>
        <button onClick={onClose}
          className="border-2 border-white/10 text-white/20 px-4 py-2 font-black uppercase italic text-xs hover:text-white transition-all ml-auto">Close</button>
      </div>
    </div>
  );
};

const ProducerStudio: React.FC<ProducerStudioProps> = ({ user, shows, initialTab, hideHeader = false, hideTabs = false }) => {
  const [tab, setTab] = useState<StudioTab>(initialTab || 'dashboard');

  const myShows = shows.filter((s: any) => s.user_id === user.id);

  // ROYALTY TRACKER STATE
  const [royaltyReports, setRoyaltyReports] = useState<any[]>([]);
  const [sellerReports, setSellerReports] = useState<any[]>([]);
  const [licensedShows, setLicensedShows] = useState<any[]>([]);
  const [newReport, setNewReport] = useState({ date: '', show: '', venue: '', tickets: '', price: '', royaltyPct: '', notes: '' });
  const [reportSaved, setReportSaved] = useState(false);
  const [reportLoading, setReportLoading] = useState(false);

  // ANALYTICS STATE
  const [analyticsInquiries, setAnalyticsInquiries] = useState<any[]>([]);
  const [analyticsDeals, setAnalyticsDeals] = useState<any[]>([]);
  const [showViews, setShowViews] = useState<any[]>([]);

  // CONTRACTS STATE
  const [contracts, setContracts] = useState<any[]>([]);
  const [contractsLoading, setContractsLoading] = useState(false);
  const [showContractForm, setShowContractForm] = useState(false);
  const [activeTemplate, setActiveTemplate] = useState<any | null>(null);
  const [templateParams, setTemplateParams] = useState<any>({});
  const [contractTemplates, setContractTemplates] = useState<any[]>([]);
  const [showNewTemplateForm, setShowNewTemplateForm] = useState(false);
  const [newTemplate, setNewTemplate] = useState({ title: '', type: 'custom', description: '', body: '' });
  const [newContract, setNewContract] = useState({ title: '', show: '', show_id: '', party: '', type: 'licensing', status: 'draft', date: '', royalty_pct: '', territory: '', start_date: '', end_date: '', notes: '' });
  const [editContractIdx, setEditContractIdx] = useState<number | null>(null);
  const [contractText, setContractText] = useState<string | null>(null);
  const [contractTextIdx, setContractTextIdx] = useState<string | null>(null);

  // Stable contract editor component — prevents re-render focus loss
  // CALCULATOR STATE
  const [calc, setCalc] = useState({ performances: '20', ticketPrice: '25', seats: '200', occupancy: '80', royaltyPct: '10', actorFee: '200', actorCount: '5', techFee: '150', techCount: '3', otherFee: '0', otherCount: '0' });

  // CONTACTS STATE
  const [contacts, setContacts] = useState<any[]>([]);
  const [contactsLoading, setContactsLoading] = useState(false);
  const [showContactForm, setShowContactForm] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', role: '', email: '', phone: '', org: '', notes: '' });

  // LOG STATE
  const [logs, setLogs] = useState<any[]>(() => load('logs'));
  const [newLog, setNewLog] = useState({ date: new Date().toISOString().split('T')[0], show: '', venue: '', attendance: '', notes: '' });

  // Save to localStorage on change
  useEffect(() => { save('logs', logs); }, [logs]);

  // Load contract templates (shared - everyone sees them)
  useEffect(() => {
    supabase.from('contract_templates').select('*').order('is_default', { ascending: false }).order('created_at', { ascending: true })
      .then(({ data }) => { if (data) setContractTemplates(data); });
  }, []);
  useEffect(() => {
    if (!user?.id) return;
    setContactsLoading(true);
    supabase.from('hahafriends').select('*').eq('user_id', user.id).order('created_at', { ascending: false })
      .then(({ data }) => { if (data) setContacts(data); setContactsLoading(false); });
  }, [user?.id]);

  // Load contracts from Supabase
  useEffect(() => {
    if (!user?.id) return;
    setContractsLoading(true);
    supabase.from('contracts').select('*').eq('user_id', user.id).order('created_at', { ascending: false })
      .then(({ data }) => { if (data) setContracts(data); setContractsLoading(false); });
  }, [user?.id]);

  // CALCULATOR
  const gross = Number(calc.ticketPrice) * Number(calc.seats) * (Number(calc.occupancy) / 100) * Number(calc.performances);
  const royalty = gross * Number(calc.royaltyPct) / 100;
  const actors = Number(calc.actorFee) * Number(calc.actorCount) * Number(calc.performances);
  const techs = Number(calc.techFee) * Number(calc.techCount) * Number(calc.performances);
  const other = Number(calc.otherFee) * Number(calc.otherCount) * Number(calc.performances);
  const totalCosts = actors + techs + other;
  const net = gross - royalty - totalCosts;

  // Load shows I have licensed (from deals where I am buyer)
  useEffect(() => {
    if (!user?.id) return;
    supabase.from('deals').select('show_title, royalty_pct, show_id').eq('buyer_email', (user as any).email)
      .then(({ data }) => { if (data) setLicensedShows(data); });
  }, [user]);

  // Load buyer reports (my own logged performances)
  const loadRoyaltyData = async () => {
    if (!user?.id) return;
    setReportLoading(true);
    
    // Buyer view - reports I logged
    const { data: buyerData } = await supabase
      .from('royalty_reports')
      .select('*')
      .eq('buyer_id', user.id)
      .order('date', { ascending: false });
    if (buyerData) setRoyaltyReports(buyerData);

    // Seller view - reports on my shows
    const myShowIds = myShows.map((s: any) => s.id).filter(Boolean);
    if (myShowIds.length > 0) {
      const { data: sellerData } = await supabase
        .from('royalty_reports')
        .select('*')
        .in('show_id', myShowIds)
        .order('date', { ascending: false });
      if (sellerData) setSellerReports(sellerData);
    }
    setReportLoading(false);
  };

  useEffect(() => {
    if (myShows.length > 0 || user?.id) loadRoyaltyData();
  }, [myShows]);

  // Load analytics data
  useEffect(() => {
    if (!user?.id) return;
    const myShowIds = shows.filter((s: any) => s.user_id === user.id).map((s: any) => s.id).filter(Boolean);
    // Inquiries na moje showe (TICKLED)
    supabase.from('inquiries').select('*').eq('producer_id', user.id).order('created_at', { ascending: false })
      .then(({ data }) => { if (data) setAnalyticsInquiries(data); });
    // Inquiries ki sem jih jaz poslal (TICKLER)
    supabase.from('inquiries').select('*').eq('recipient_id', user.id).order('created_at', { ascending: false })
      .then(({ data }) => { if (data) setAnalyticsDeals(data); });
    // Timestamped views
    if (myShowIds.length > 0) {
      supabase.from('show_views').select('show_id, created_at').in('show_id', myShowIds)
        .gte('created_at', new Date(Date.now() - 56 * 24 * 60 * 60 * 1000).toISOString()) // last 8 weeks
        .then(({ data }) => { if (data) setShowViews(data); });
    }
  }, [user?.id]);

  const inp = 'w-full bg-brand-black border-2 border-white/20 p-2 text-white font-bold outline-none focus:border-brand-yellow text-sm';
  const lbl = 'text-[9px] font-black uppercase tracking-widest text-white/40 italic mb-1 block';

  const tabs: { key: StudioTab; label: string; icon: string }[] = [
    { key: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
    { key: 'royalty', label: 'Royalty Tracker', icon: 'receipt_long' },
    { key: 'incoming', label: 'Incoming Royalties', icon: 'savings' },
    { key: 'contracts', label: 'PAPERWORK', icon: 'description' },
    { key: 'calculator', label: 'Calculator', icon: 'calculate' },
    { key: 'contacts', label: 'HAHAfriends', icon: 'contacts' },
    { key: 'log', label: 'Show Log', icon: 'history' },
  ];

  return (
    <section className="space-y-6 text-white">
      {!hideHeader && (
      <div>
        <h2 className="text-4xl font-black uppercase italic">Producer <span className="text-brand-pink">Studio</span></h2>
        <p className="text-white/40 font-bold italic text-sm mt-1">ROAR exclusive · Your production command center</p>
        <p className="text-brand-yellow/60 text-[9px] font-black uppercase italic tracking-widest mt-2">Studio data is saved on this device only. Use the same browser to access your data.</p>
      </div>
      )}

      {/* STUDIO TABS */}
      {!hideTabs && <div className="flex gap-2 flex-wrap border-b-2 border-white/10 pb-4">
        {tabs.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`flex items-center gap-2 px-4 py-2 text-[10px] font-black uppercase italic transition-all border-2 ${tab === t.key ? 'bg-brand-pink text-white border-brand-pink' : 'border-white/20 text-white/40 hover:border-white hover:text-white'}`}>
            <span className="material-symbols-outlined text-sm">{t.icon}</span>
            {t.label}
          </button>
        ))}
      </div>}

      {/* ── DASHBOARD ── */}
      {tab === 'dashboard' && (() => {
        // ── HELPERS ──
        const totalViews = myShows.reduce((s: number, sh: any) => s + (sh.viewsCount || 0), 0);
        const totalInq = analyticsInquiries.length > 0
          ? analyticsInquiries.length
          : myShows.reduce((s: number, sh: any) => s + (sh.inquiriesCount || 0), 0);
        const conversion = totalViews > 0 ? Math.round((totalInq / totalViews) * 100) : 0;
        const activeDeals = analyticsInquiries.filter((i: any) => ['contacted','negotiating','contract_sent'].includes(i.deal_status || '')).length;
        const signedDeals = analyticsInquiries.filter((i: any) => ['signed','royalties','completed'].includes(i.deal_status || '')).length;
        const totalRoyaltiesEarned = sellerReports.reduce((s: number, r: any) => s + Number(r.royalty_amount || 0), 0);

        // ── WEEKLY VIEWS CHART (last 8 weeks) ──
        const now = new Date();
        const weeks = Array.from({ length: 8 }, (_, i) => {
          const weekStart = new Date(now);
          weekStart.setDate(now.getDate() - (7 * (7 - i)));
          weekStart.setHours(0, 0, 0, 0);
          const weekEnd = new Date(weekStart);
          weekEnd.setDate(weekStart.getDate() + 7);
          const label = weekStart.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
          const count = showViews.filter(v => {
            const d = new Date(v.created_at);
            return d >= weekStart && d < weekEnd;
          }).length;
          return { label, count };
        });
        const maxViews = Math.max(...weeks.map(w => w.count), 1);

        // ── MONTHLY INQUIRIES (last 6 months) ──
        const months = Array.from({ length: 6 }, (_, i) => {
          const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
          const label = d.toLocaleDateString('en-GB', { month: 'short' });
          const count = analyticsInquiries.filter(inq => {
            const id = new Date(inq.created_at);
            return id.getMonth() === d.getMonth() && id.getFullYear() === d.getFullYear();
          }).length;
          return { label, count };
        });
        const maxInq = Math.max(...months.map(m => m.count), 1);

        // ── TOP TERRITORIES ──
        const terrCount: Record<string, number> = {};
        analyticsInquiries.forEach((i: any) => { if (i.territory) terrCount[i.territory] = (terrCount[i.territory] || 0) + 1; });
        const topTerritories = Object.entries(terrCount).sort((a, b) => b[1] - a[1]).slice(0, 5);
        const maxTerrCount = topTerritories[0]?.[1] || 1;

        // ── PACKAGE SPLIT ──
        const fpCount = analyticsInquiries.filter((i: any) => i.package_type === 'full_punch').length;
        const scriptCount = analyticsInquiries.filter((i: any) => i.package_type !== 'full_punch').length;
        const fpPct = totalInq > 0 ? Math.round((fpCount / totalInq) * 100) : 0;

        return (
          <div className="space-y-6">

            {/* TOP KPI CARDS */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: 'Total Views', value: totalViews.toLocaleString(), color: 'text-brand-yellow', sub: 'all time', icon: 'visibility' },
                { label: 'Tickles', value: totalInq.toString(), color: 'text-brand-pink', sub: 'inquiries received', icon: 'touch_app' },
                { label: 'Conversion', value: conversion + '%', color: 'text-brand-cyan', sub: 'views → inquiries', icon: 'trending_up' },
                { label: 'Royalties', value: '€' + totalRoyaltiesEarned.toLocaleString(), color: 'text-green-400', sub: 'earned to date', icon: 'payments' },
              ].map((s, i) => (
                <div key={i} className="border-4 border-white/10 p-4 hover:border-white/20 transition-all">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-[8px] font-black uppercase italic text-white/30">{s.label}</p>
                    <span className="material-symbols-outlined text-sm text-white/15">{s.icon}</span>
                  </div>
                  <p className={"text-3xl font-black " + s.color}>{s.value}</p>
                  <p className="text-[8px] text-white/20 mt-1">{s.sub}</p>
                </div>
              ))}
            </div>

            {/* CONVERSION FUNNEL */}
            <div className="border-4 border-white/10 p-5">
              <p className="text-[9px] font-black uppercase tracking-widest text-brand-cyan italic mb-4">Conversion Funnel</p>
              <div className="flex items-end gap-0">
                {[
                  { label: 'Views', value: totalViews, color: 'bg-brand-yellow', pct: 100 },
                  { label: 'Inquiries', value: totalInq, color: 'bg-brand-pink', pct: totalViews > 0 ? Math.round((totalInq / totalViews) * 100) : 0 },
                  { label: 'Active', value: activeDeals, color: 'bg-brand-cyan', pct: totalInq > 0 ? Math.round((activeDeals / totalInq) * 100) : 0 },
                  { label: 'Signed', value: signedDeals, color: 'bg-green-500', pct: totalInq > 0 ? Math.round((signedDeals / totalInq) * 100) : 0 },
                ].map((f, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-2">
                    <p className="text-sm font-black text-white">{f.value}</p>
                    <div className="w-full flex justify-center">
                      <div className={f.color + " transition-all"} style={{ width: '80%', height: Math.max(f.pct * 0.6, 4) + 'px', minHeight: '4px' }} />
                    </div>
                    <p className="text-[8px] font-black uppercase italic text-white/30">{f.label}</p>
                    {i > 0 && <p className="text-[8px] text-white/20">{f.pct}%</p>}
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

              {/* WEEKLY VIEWS CHART */}
              <div className="border-4 border-white/10 p-5">
                <p className="text-[9px] font-black uppercase tracking-widest text-brand-yellow italic mb-4">
                  Weekly Views — Last 8 Weeks
                  {showViews.length === 0 && <span className="text-white/20 normal-case font-normal ml-2">(tracking starts now)</span>}
                </p>
                <div className="flex items-end gap-1.5 h-24">
                  {weeks.map((w, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <p className="text-[7px] text-white/30 font-black">{w.count > 0 ? w.count : ''}</p>
                      <div className="w-full bg-brand-yellow/20 relative" style={{ height: '60px' }}>
                        <div className="w-full bg-brand-yellow absolute bottom-0 transition-all"
                          style={{ height: Math.max((w.count / maxViews) * 60, w.count > 0 ? 3 : 0) + 'px' }} />
                      </div>
                      <p className="text-[6px] text-white/20 font-black text-center leading-tight">{w.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* MONTHLY INQUIRIES */}
              <div className="border-4 border-white/10 p-5">
                <p className="text-[9px] font-black uppercase tracking-widest text-brand-pink italic mb-4">Monthly Inquiries — Last 6 Months</p>
                <div className="flex items-end gap-1.5 h-24">
                  {months.map((m, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <p className="text-[7px] text-white/30 font-black">{m.count > 0 ? m.count : ''}</p>
                      <div className="w-full bg-brand-pink/20 relative" style={{ height: '60px' }}>
                        <div className="w-full bg-brand-pink absolute bottom-0 transition-all"
                          style={{ height: Math.max((m.count / maxInq) * 60, m.count > 0 ? 3 : 0) + 'px' }} />
                      </div>
                      <p className="text-[7px] text-white/30 font-black">{m.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* TOP TERRITORIES */}
              <div className="border-4 border-white/10 p-5">
                <p className="text-[9px] font-black uppercase tracking-widest text-brand-cyan italic mb-4">Top Territories</p>
                {topTerritories.length === 0 ? (
                  <p className="text-white/20 text-xs italic">No territory data yet.</p>
                ) : (
                  <div className="space-y-2">
                    {topTerritories.map(([territory, count]) => (
                      <div key={territory} className="flex items-center gap-3">
                        <p className="text-xs font-black text-white w-24 flex-shrink-0 uppercase">{territory}</p>
                        <div className="flex-1 bg-white/5 h-5 relative">
                          <div className="bg-brand-cyan h-5 absolute left-0 top-0 transition-all"
                            style={{ width: Math.round((count / maxTerrCount) * 100) + '%' }} />
                          <p className="absolute right-2 top-0 h-5 flex items-center text-[8px] font-black text-black z-10"
                            style={{ color: (count / maxTerrCount) > 0.4 ? '#000' : 'rgba(255,255,255,0.5)' }}>{count}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* PACKAGE SPLIT */}
              <div className="border-4 border-white/10 p-5">
                <p className="text-[9px] font-black uppercase tracking-widest text-brand-pink italic mb-4">Package Interest</p>
                {totalInq === 0 ? (
                  <p className="text-white/20 text-xs italic">No inquiries yet.</p>
                ) : (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-[9px] font-black uppercase text-brand-pink">🥊 Full Punch</span>
                        <span className="text-[9px] font-black text-white">{fpCount} · {fpPct}%</span>
                      </div>
                      <div className="w-full bg-white/5 h-4">
                        <div className="bg-brand-pink h-4 transition-all" style={{ width: fpPct + '%' }} />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-[9px] font-black uppercase text-brand-yellow">📄 Script Only</span>
                        <span className="text-[9px] font-black text-white">{scriptCount} · {100 - fpPct}%</span>
                      </div>
                      <div className="w-full bg-white/5 h-4">
                        <div className="bg-brand-yellow h-4 transition-all" style={{ width: (100 - fpPct) + '%' }} />
                      </div>
                    </div>
                    <p className="text-[8px] text-white/20 italic">{totalInq} total inquiries</p>
                  </div>
                )}
              </div>
            </div>

            {/* PER SHOW */}
            <div>
              <p className="text-[9px] font-black uppercase tracking-widest text-white/30 italic mb-3">Per Show Breakdown</p>
              {myShows.length === 0 ? (
                <div className="py-10 text-center">
                  <p className="text-4xl mb-2">📊</p>
                  <p className="text-white/20 font-black uppercase italic text-sm">No shows yet.</p>
                </div>
              ) : myShows.map((show: any) => {
                const showInq = analyticsInquiries.filter((i: any) => i.show_id === show.id);
                const showRep = sellerReports.filter((r: any) => r.show_id === show.id);
                const showViewsData = showViews.filter((v: any) => v.show_id === show.id);
                const royaltiesShow = showRep.reduce((s: number, r: any) => s + Number(r.royalty_amount || 0), 0);
                const audienceShow = showRep.reduce((s: number, r: any) => s + Number(r.tickets || 0), 0);
                const viewsShow = show.viewsCount || 0;
                const convShow = viewsShow > 0 ? Math.round((showInq.length / viewsShow) * 100) : 0;
                const signed = showInq.filter((i: any) => ['signed','royalties','completed'].includes(i.deal_status || '')).length;
                const active = showInq.filter((i: any) => ['contacted','negotiating','contract_sent'].includes(i.deal_status || '')).length;
                const territories = [...new Set(showInq.map((i: any) => i.territory).filter(Boolean))] as string[];
                return (
                  <div key={show.id} className="border-4 border-white/10 hover:border-white/20 transition-all mb-3">
                    <div className="flex items-center justify-between gap-4 px-5 py-3 border-b border-white/10">
                      <div className="flex items-center gap-3">
                        {show.imageUrl && <img src={show.imageUrl} className="w-8 h-12 object-cover" alt="" />}
                        <div>
                          <p className="font-black uppercase italic text-white">{show.title}</p>
                          <p className="text-white/30 text-[10px]">{show.genre} · {show.duration} min</p>
                        </div>
                      </div>
                      <div className="flex gap-1.5">
                        {signed > 0 && <span className="text-[7px] font-black uppercase bg-green-500/20 text-green-400 px-2 py-0.5">{signed} SIGNED</span>}
                        {active > 0 && <span className="text-[7px] font-black uppercase bg-brand-yellow/20 text-brand-yellow px-2 py-0.5">{active} ACTIVE</span>}
                      </div>
                    </div>
                    <div className="grid grid-cols-3 md:grid-cols-6 divide-x divide-white/10">
                      {[
                        { label: 'Views', value: viewsShow.toLocaleString(), color: 'text-brand-yellow' },
                        { label: 'Inquiries', value: showInq.length, color: 'text-brand-pink' },
                        { label: 'Conv.', value: convShow + '%', color: 'text-brand-cyan' },
                        { label: 'Perfs.', value: showRep.length, color: 'text-white' },
                        { label: 'Audience', value: audienceShow.toLocaleString(), color: 'text-white' },
                        { label: 'Royalties', value: '€' + royaltiesShow.toLocaleString(), color: 'text-brand-yellow' },
                      ].map((s, i) => (
                        <div key={i} className="p-3 text-center">
                          <p className="text-[7px] font-black uppercase italic text-white/25 mb-1">{s.label}</p>
                          <p className={"text-lg font-black " + s.color}>{s.value}</p>
                        </div>
                      ))}
                    </div>
                    {territories.length > 0 && (
                      <div className="px-5 py-2 border-t border-white/10 flex items-center gap-2 flex-wrap">
                        <p className="text-[8px] font-black uppercase italic text-white/20">From:</p>
                        {territories.map((t: string) => <span key={t} className="text-[8px] font-black uppercase border border-white/15 text-white/40 px-1.5 py-0.5">{t}</span>)}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

          </div>
        );
      })()}

      {/* ── SCHEDULE ── */}
      {/* ── ROYALTY TRACKER ── */}
      {tab === 'royalty' && (
        <div className="space-y-6">
          <div className="border-l-4 border-brand-yellow pl-4">
            <p className="text-white font-black uppercase italic text-sm">Performance Log</p>
            <p className="text-white/50 text-sm italic mt-1">As a licensee, log every performance of a show you have licensed. Enter tickets sold and ticket price — royalty is calculated automatically and sent to the rights holder. This is your legal obligation under the licensing agreement.</p>
          </div>

          {/* ADD REPORT FORM */}
          <div className="border-4 border-brand-yellow/30 p-4 space-y-4">
            <p className="text-[9px] font-black uppercase italic text-brand-yellow tracking-widest">Log Performance</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div><label className={lbl}>Date</label><input type="date" value={newReport.date} onChange={e => setNewReport(p => ({...p, date: e.target.value}))} className={inp} /></div>
              <div><label className={lbl}>Show <span className="text-brand-cyan">(licensed)</span></label>
                <select value={newReport.show} onChange={e => {
                  const sel = licensedShows.find((s: any) => s.show_title === e.target.value);
                  setNewReport(p => ({...p, show: e.target.value, royaltyPct: sel?.royalty_pct || p.royaltyPct}));
                }} className={inp}>
                  <option value="">Select licensed show...</option>
                  {licensedShows.map((s: any, i: number) => <option key={i} value={s.show_title}>{s.show_title}</option>)}
                  {licensedShows.length === 0 && <option disabled value="">No licensed shows found. License a show first.</option>}
                </select>
              </div>
              <div><label className={lbl}>Venue</label><input placeholder="Theatre name" value={newReport.venue} onChange={e => setNewReport(p => ({...p, venue: e.target.value}))} className={inp} /></div>
              <div><label className={lbl}>Tickets Sold</label><input type="number" placeholder="e.g. 180" value={newReport.tickets} onChange={e => setNewReport(p => ({...p, tickets: e.target.value}))} className={inp} /></div>
              <div><label className={lbl}>Ticket Price (€)</label><input type="number" placeholder="e.g. 25" value={newReport.price} onChange={e => setNewReport(p => ({...p, price: e.target.value}))} className={inp} /></div>
              <div><label className={lbl}>Royalty %</label><input type="number" placeholder="e.g. 10" value={newReport.royaltyPct} onChange={e => setNewReport(p => ({...p, royaltyPct: e.target.value}))} className={inp} /></div>
              <div className="col-span-2 md:col-span-3"><label className={lbl}>Notes</label><input placeholder="Optional notes..." value={newReport.notes} onChange={e => setNewReport(p => ({...p, notes: e.target.value}))} className={inp} /></div>
            </div>

            {/* LIVE CALC */}
            {newReport.tickets && newReport.price && newReport.royaltyPct && (
              <div className="bg-brand-black border-4 border-brand-cyan p-4 flex items-center gap-8">
                <div>
                  <p className="text-[9px] font-black uppercase text-white/30 italic">Gross Box Office</p>
                  <p className="text-2xl font-black text-white">€{Math.round(Number(newReport.tickets) * Number(newReport.price)).toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-[9px] font-black uppercase text-brand-yellow italic">Royalty Due</p>
                  <p className="text-2xl font-black text-brand-yellow">€{Math.round(Number(newReport.tickets) * Number(newReport.price) * Number(newReport.royaltyPct) / 100).toLocaleString()}</p>
                </div>
              </div>
            )}

            <button onClick={async () => {
              if (!newReport.date || !newReport.show || !newReport.tickets) return;
              const royaltyAmount = Math.round(Number(newReport.tickets) * Number(newReport.price) * Number(newReport.royaltyPct) / 100);
              const gross = Math.round(Number(newReport.tickets) * Number(newReport.price));
              const show = myShows.find((s: any) => s.title === newReport.show);
              await supabase.from('royalty_reports').insert({
                show_id: show?.id,
                show_title: newReport.show,
                buyer_id: user.id,
                buyer_name: user.name,
                date: newReport.date,
                venue: newReport.venue,
                tickets: Number(newReport.tickets),
                ticket_price: Number(newReport.price),
                royalty_pct: Number(newReport.royaltyPct),
                royalty_amount: royaltyAmount,
                gross,
                notes: newReport.notes,
              });
              await loadRoyaltyData();
              setNewReport({ date: '', show: '', venue: '', tickets: '', price: '', royaltyPct: '', notes: '' });
              setReportSaved(true); setTimeout(() => setReportSaved(false), 3000);
            }} className="bg-brand-yellow text-black px-6 py-2 font-black uppercase italic text-xs border-2 border-black hover:bg-white transition-all">
              + Log Performance
            </button>
            {reportSaved && <p className="text-brand-cyan text-xs font-black italic">✓ Performance logged!</p>}
          </div>

          {/* SUMMARY */}
          {royaltyReports.length > 0 && (
            <div className="border-4 border-white/10 p-4 grid grid-cols-3 gap-4">
              <div className="text-center">
                <p className="text-[9px] font-black uppercase text-white/30 italic">Total Performances</p>
                <p className="text-3xl font-black text-white">{royaltyReports.length}</p>
              </div>
              <div className="text-center border-x border-white/10">
                <p className="text-[9px] font-black uppercase text-white/30 italic">Total Box Office</p>
                <p className="text-3xl font-black text-brand-cyan">€{royaltyReports.reduce((s, r) => s + (r.gross || 0), 0).toLocaleString()}</p>
              </div>
              <div className="text-center">
                <p className="text-[9px] font-black uppercase text-brand-yellow italic">Total Royalties Due</p>
                <p className="text-3xl font-black text-brand-yellow">€{royaltyReports.reduce((s, r) => s + (r.royaltyAmount || 0), 0).toLocaleString()}</p>
              </div>
            </div>
          )}

          {/* SELLER VIEW — reports from buyers for my shows */}
          <div className="border-t-4 border-white/10 pt-6 space-y-4">
            <p className="text-[9px] font-black uppercase italic text-brand-pink tracking-widest">Rights Holder View — Reports on Your Shows</p>
            {myShows.length === 0 ? (
              <p className="text-white/20 italic text-sm">No shows uploaded yet.</p>
            ) : (
              <div className="space-y-3">
                {myShows.map((show: any) => {
                  const showReports = sellerReports.filter((r: any) => r.show_id === show.id);
                  const totalRoyalty = showReports.reduce((s: number, r: any) => s + (r.royalty_amount || 0), 0);
                  const totalGross = showReports.reduce((s: number, r: any) => s + (r.gross || 0), 0);
                  return (
                    <div key={show.id} className="border-4 border-white/10 p-4 hover:border-brand-pink transition-all">
                      <div className="flex items-center justify-between mb-3">
                        <p className="font-black uppercase italic text-white">{show.title}</p>
                        <span className="text-brand-pink font-black text-lg">€{totalRoyalty.toLocaleString()} due</span>
                      </div>
                      <div className="grid grid-cols-3 gap-3 text-center">
                        <div>
                          <p className="text-[9px] font-black uppercase text-white/30 italic">Performances</p>
                          <p className="text-xl font-black text-white">{showReports.length}</p>
                        </div>
                        <div className="border-x border-white/10">
                          <p className="text-[9px] font-black uppercase text-white/30 italic">Box Office</p>
                          <p className="text-xl font-black text-brand-cyan">€{totalGross.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-[9px] font-black uppercase text-brand-pink italic">Royalties</p>
                          <p className="text-xl font-black text-brand-pink">€{totalRoyalty.toLocaleString()}</p>
                        </div>
                      </div>
                      {showReports.length > 0 && (
                        <div className="mt-3 space-y-1">
                          {showReports.map((r: any, i: number) => (
                            <div key={i} className="flex items-center justify-between text-xs border-t border-white/5 pt-1">
                              <span className="text-white/40">{r.date ? new Date(r.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) : '—'} · {r.venue || '—'} · {r.buyer_name || 'Buyer'}</span>
                              <span className="text-brand-yellow font-black">€{(r.royalty_amount || 0).toLocaleString()}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* REPORTS LIST */}
          {royaltyReports.length === 0 ? (
            <p className="text-white/20 italic text-sm">No performances logged yet.</p>
          ) : (
            <div className="space-y-2">
              <div className="grid grid-cols-6 gap-2 text-[9px] font-black uppercase italic text-white/30 px-4 pb-2">
                <span>Date</span><span>Show</span><span>Venue</span><span>Tickets</span><span>Gross</span><span>Royalty Due</span>
              </div>
              {royaltyReports.map((r, i) => (
                <div key={r.id || i} className="border-2 border-white/10 px-4 py-3 grid grid-cols-6 gap-2 items-center hover:border-brand-yellow transition-all">
                  <span className="text-brand-yellow font-black text-sm">{new Date(r.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</span>
                  <span className="text-white font-black italic text-xs truncate">{r.show}</span>
                  <span className="text-white/40 text-xs truncate">{r.venue}</span>
                  <span className="text-white/60 text-sm">{r.tickets}</span>
                  <span className="text-brand-cyan font-black text-sm">€{(r.gross || 0).toLocaleString()}</span>
                  <div className="flex items-center justify-between">
                    <span className="text-brand-yellow font-black text-sm">€{(r.royaltyAmount || 0).toLocaleString()}</span>
                    <button onClick={() => setRoyaltyReports(prev => prev.filter((_, j) => j !== i))} className="text-white/20 hover:text-brand-pink transition-colors">
                      <span className="material-symbols-outlined text-sm">close</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

            {tab === 'contracts' && (
        <div className="space-y-6">

          {/* ══ MY CONTRACTS ══ */}
          <div className="flex items-center justify-between">
            <p className="font-black uppercase italic text-white">PAPERWORK <span className="text-white/30 font-normal text-xs">· {contracts.length} contract{contracts.length !== 1 ? 's' : ''}</span></p>
            <button onClick={() => setShowContractForm(true)}
              className="bg-brand-yellow text-black px-4 py-2 font-black uppercase italic text-xs border-2 border-black hover:bg-white transition-all">
              + New Contract
            </button>
          </div>

          {/* NEW CONTRACT — choose template */}
          {showContractForm && (
            <div className="border-4 border-brand-yellow/40 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-[9px] font-black uppercase italic text-brand-yellow tracking-widest">Choose a template</p>
                <button onClick={() => { setShowContractForm(false); setActiveTemplate(null); }} className="text-white/30 hover:text-white font-black uppercase italic text-xs">✕ Close</button>
              </div>

              {!activeTemplate ? (
                <div className="space-y-2">
                  {contractTemplates.map((tmpl: any) => (
                    <button key={tmpl.id} onClick={() => {
                      setActiveTemplate(tmpl);
                      setTemplateParams({
                        show: myShows[0]?.title || '', show_id: myShows[0]?.id || '',
                        royalty: myShows[0]?.scriptRoyaltyPct || '10', share_b: '',
                        party: '', org: '', territory: '', city: '', performances: '',
                        start_date: '', end_date: '', advance: '0', currency: 'EUR',
                        rights_holder: user.name, rights_holder_org: '', rights_holder_address: '',
                        rights_holder_email: (user as any).email || '', licensee_address: '', licensee_email: '',
                        language: '', date: new Date().toISOString().split('T')[0],
                        package: 'Script License', governing_law: '', author: myShows[0]?.author || '',
                        ref: Date.now().toString().slice(-6),
                      });
                    }} className="w-full text-left border-2 border-white/10 hover:border-brand-yellow px-4 py-3 transition-all flex items-center justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-black uppercase italic text-white text-sm">{tmpl.title}</p>
                          {tmpl.is_default && <span className="text-[7px] font-black uppercase bg-brand-yellow/20 text-brand-yellow px-1.5 py-0.5">HahaHub</span>}
                          {!tmpl.is_default && <span className="text-[7px] font-black uppercase bg-white/10 text-white/30 px-1.5 py-0.5">Mine</span>}
                        </div>
                        {tmpl.description && <p className="text-white/30 text-[9px] italic mt-0.5">{tmpl.description}</p>}
                      </div>
                      <span className="text-brand-yellow font-black uppercase italic text-xs flex-shrink-0">Use →</span>
                    </button>
                  ))}
                </div>
              ) : (() => {
                const tmpl = activeTemplate;
                const p = templateParams;
                const placeholders = [...new Set((tmpl.body.match(/\{\{(\w+)\}\}/g) || []).map((m: string) => m.replace(/\{\{|\}\}/g, '')))].filter((ph: string) => !['ref','share_b'].includes(ph as string)) as string[];
                const labels: any = { show:'Show', party:'Counter Party', org:'Organisation / Theatre', rights_holder:'Rights Holder', rights_holder_org:'Rights Holder Organisation', rights_holder_address:'Rights Holder Address', rights_holder_email:'Rights Holder Email', licensee_address:'Licensee Address', licensee_email:'Licensee Email', royalty:'Royalty %', share_b:'Counter Party Share %', territory:'Territory', city:'City / Venue', start_date:'Start Date', end_date:'End Date', advance:'Fee / Advance (EUR)', performances:'Number of Performances', governing_law:'Governing Law', author:'Author', language:'Original Language', package:'Package', currency:'Currency', date:'Contract Date' };
                const inputType: any = { start_date:'date', end_date:'date', date:'date', royalty:'number', advance:'number', performances:'number' };
                const selectOptions: any = { package:['Script License','Full Punch Package'], currency:['EUR','USD','GBP','CHF'] };

                const generateText = () => {
                  let text = tmpl.body;
                  const vals: any = { ...p, date: p.date || new Date().toISOString().split('T')[0], ref: p.ref || Date.now().toString().slice(-6), share_b: String(100 - Number(p.royalty || 50)) };
                  Object.entries(vals).forEach(([k, v]) => { text = text.replace(new RegExp(`\\{\\{${k}\\}\\}`, 'g'), String(v || `[${k.toUpperCase()}]`)); });
                  text = text.replace(/\{\{(\w+)\}\}/g, (_: string, k: string) => `[${k.toUpperCase()}]`);
                  return text;
                };

                return (
                  <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{background:'rgba(0,0,0,0.85)'}}>
                    <div className="bg-brand-black border-4 border-brand-yellow w-full max-w-3xl max-h-[90vh] overflow-y-auto">
                      <div className="sticky top-0 bg-brand-black border-b-4 border-brand-yellow px-6 py-4 flex items-center justify-between z-10">
                        <div>
                          <p className="font-black uppercase italic text-brand-yellow text-lg">{tmpl.title}</p>
                          {tmpl.description && <p className="text-white/30 text-[9px] italic">{tmpl.description}</p>}
                        </div>
                        <button onClick={() => setActiveTemplate(null)} className="text-white/40 hover:text-white font-black uppercase italic text-sm border-2 border-white/20 px-3 py-1 hover:border-white transition-all">✕ Close</button>
                      </div>
                      <div className="p-6 space-y-5">
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {placeholders.map((ph: string) => (
                        <div key={ph}>
                          <label className={lbl}>{labels[ph] || ph.replace(/_/g,' ')}</label>
                          {ph === 'show' ? (
                            <select value={p[ph]||''} onChange={e => { const sel = myShows.find((s:any) => s.title===e.target.value); setTemplateParams((prev:any) => ({...prev, show:e.target.value, show_id:sel?.id||'', author:sel?.author||prev.author, royalty:sel?.scriptRoyaltyPct||prev.royalty})); }} className={inp}>
                              <option value="">Select show...</option>
                              {myShows.map((s:any) => <option key={s.id} value={s.title}>{s.title}</option>)}
                            </select>
                          ) : selectOptions[ph] ? (
                            <select value={p[ph]||''} onChange={e => setTemplateParams((prev:any) => ({...prev,[ph]:e.target.value}))} className={inp}>
                              {selectOptions[ph].map((o:string) => <option key={o} value={o}>{o}</option>)}
                            </select>
                          ) : (
                            <input type={inputType[ph]||'text'} value={p[ph]||''} onChange={e => setTemplateParams((prev:any) => ({...prev,[ph]:e.target.value}))} className={inp} placeholder={labels[ph]||ph} />
                          )}
                        </div>
                      ))}
                    </div>

                    <div>
                      <p className="text-[9px] font-black uppercase italic text-white/20 tracking-widest mb-1">Preview</p>
                      <pre className="w-full bg-black border-2 border-white/10 p-4 text-white/50 font-mono text-[10px] leading-relaxed whitespace-pre-wrap max-h-48 overflow-y-auto">{generateText()}</pre>
                    </div>

                    <div className="flex gap-2 flex-wrap">
                      <button onClick={async () => {
                        if (!user?.id) return;
                        const body = generateText();
                        const title = `${tmpl.title}${p.party ? ' — ' + p.party : ''}${p.show ? ' · ' + p.show : ''}`;
                        const { data } = await supabase.from('contracts').insert({ user_id:user.id, title, show:p.show, show_id:p.show_id||null, party:p.party, type:tmpl.type, status:'draft', royalty_pct:p.royalty?Number(p.royalty):null, territory:p.territory||null, start_date:p.start_date||null, end_date:p.end_date||null, body, notes:`Template: ${tmpl.title}` }).select().single();
                        if (data) setContracts(prev => [data,...prev]);
                        setShowContractForm(false); setActiveTemplate(null);
                      }} className="bg-brand-yellow text-black px-6 py-3 font-black uppercase italic text-sm border-4 border-black hover:bg-white transition-all">
                        💾 Save Contract
                      </button>
                      <button onClick={() => { const blob = new Blob([generateText()],{type:'text/plain'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=`contract_${p.party||'party'}.txt`.replace(/\s+/g,'_'); a.click(); }}
                        className="border-4 border-brand-cyan/40 text-brand-cyan px-4 py-3 font-black uppercase italic text-sm hover:bg-brand-cyan hover:text-black transition-all">
                        📥 .txt
                      </button>
                      <button onClick={() => { const w=window.open('','_blank'); if(w){w.document.write(`<html><head><style>body{font-family:monospace;padding:40px;font-size:13px;line-height:1.8;}</style></head><body><pre>${generateText()}</pre></body></html>`); w.document.close(); w.print(); }}}
                        className="border-4 border-white/20 text-white/40 px-4 py-3 font-black uppercase italic text-sm hover:text-white transition-all">
                        🖨️ Print
                      </button>
                    </div>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* CONTRACTS LIST */}
          {contractsLoading ? (
            <p className="text-white/20 italic text-sm">Loading...</p>
          ) : contracts.length === 0 ? (
            <div className="py-10 text-center space-y-2">
              <p className="text-4xl">📄</p>
              <p className="text-white/20 font-black uppercase italic text-sm">No contracts yet.</p>
              <p className="text-white/10 text-xs italic">Click + New Contract above.</p>
            </div>
          ) : contracts.map((c: any) => (
            <div key={c.id} className="border-4 border-white/10 hover:border-white/20 transition-all">
              <div className="px-5 py-4 flex items-start justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <p className="font-black uppercase italic text-white">{c.title}</p>
                    <span className={`text-[8px] font-black uppercase px-2 py-0.5 flex-shrink-0 ${c.status==='signed'?'bg-green-500/20 text-green-400 border border-green-500/30':c.status==='sent'?'bg-brand-yellow text-black':c.status==='expired'?'bg-red-500/20 text-red-400':'border border-white/20 text-white/30'}`}>{c.status}</span>
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-0.5">
                    {c.party && <p className="text-white/40 text-xs">👤 {c.party}</p>}
                    {c.show && <p className="text-white/40 text-xs">🎭 {c.show}</p>}
                    {c.territory && <p className="text-white/40 text-xs">🌍 {c.territory}</p>}
                    {c.royalty_pct && <p className="text-brand-yellow text-xs font-black">{c.royalty_pct}%</p>}
                    {c.start_date && <p className="text-white/30 text-xs">{c.start_date}{c.end_date?' → '+c.end_date:''}</p>}
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button onClick={async () => {
                    if (contractTextIdx === c.id) { setContractTextIdx(null); return; }
                    // Always load fresh from DB
                    const { data } = await supabase.from('contracts').select('body').eq('id', c.id).single();
                    setContractText(data?.body || '');
                    setContractTextIdx(c.id);
                  }}
                    className={"text-[8px] font-black uppercase italic px-2 py-1 border transition-all "+(contractTextIdx===c.id?'border-brand-yellow text-brand-yellow':'border-white/20 text-white/30 hover:border-brand-yellow hover:text-brand-yellow')}>
                    ✏️ Edit
                  </button>
                  <select value={c.status} onChange={async e => { await supabase.from('contracts').update({status:e.target.value}).eq('id',c.id); setContracts(prev=>prev.map(x=>x.id===c.id?{...x,status:e.target.value}:x)); }}
                    className="bg-brand-black border border-white/20 text-white/50 font-black uppercase italic text-[8px] px-2 py-1 outline-none">
                    <option value="draft">Draft</option>
                    <option value="sent">Sent</option>
                    <option value="signed">Signed</option>
                    <option value="expired">Expired</option>
                  </select>
                  <button onClick={async () => { await supabase.from('contracts').delete().eq('id',c.id); setContracts(prev=>prev.filter(x=>x.id!==c.id)); }}
                    className="text-white/20 hover:text-brand-pink transition-colors">
                    <span className="material-symbols-outlined text-sm">delete</span>
                  </button>
                </div>
              </div>

              {contractTextIdx===c.id && <ContractEditor key={c.id} c={c} initialText={contractText || ''} onSave={async (id, text) => { await supabase.from('contracts').update({ body: text }).eq('id', id); setContracts(prev => prev.map(x => x.id === id ? { ...x, body: text } : x)); }} onClose={() => setContractTextIdx(null)} />}
            </div>
          ))}

          {/* ══ TEMPLATES ══ */}
          <div className="border-t-4 border-white/10 pt-5 space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-[9px] font-black uppercase italic text-brand-cyan tracking-widest">Templates</p>
              <button onClick={() => setShowNewTemplateForm(!showNewTemplateForm)}
                className="text-[9px] font-black uppercase italic text-brand-cyan border border-brand-cyan/30 px-3 py-1.5 hover:bg-brand-cyan hover:text-black transition-all">
                + New Template
              </button>
            </div>

            {showNewTemplateForm && (
              <div className="border-4 border-brand-cyan/30 p-4 space-y-3">
                <p className="text-[9px] font-black uppercase italic text-brand-cyan tracking-widest">New Template — private, only you</p>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className={lbl}>Title *</label><input value={newTemplate.title} onChange={e=>setNewTemplate(p=>({...p,title:e.target.value}))} className={inp} placeholder="e.g. Set Designer Contract" /></div>
                  <div><label className={lbl}>Tip</label>
                    <select value={newTemplate.type} onChange={e=>setNewTemplate(p=>({...p,type:e.target.value}))} className={inp}>
                      <option value="licensing">Licensing</option>
                      <option value="coproduction">Co-production</option>
                      <option value="guest">Guest Performance</option>
                      <option value="custom">Custom</option>
                    </select>
                  </div>
                  <div className="col-span-2"><label className={lbl}>Description (optional)</label><input value={newTemplate.description} onChange={e=>setNewTemplate(p=>({...p,description:e.target.value}))} className={inp} placeholder="What is this template for?" /></div>
                </div>
                <div>
                  <label className={lbl}>Template Body *</label>
                  <p className="text-[8px] text-white/20 italic mb-1">Uporabi {'{{placeholders}}'} za polja ki se izpolnijo: {'{{party}}'}, {'{{show}}'}, {'{{royalty}}'}, {'{{territory}}'}, {'{{start_date}}'}, {'{{end_date}}'}, {'{{advance}}'}</p>
                  <textarea value={newTemplate.body} onChange={e=>setNewTemplate(p=>({...p,body:e.target.value}))} rows={10}
                    className={inp+' font-mono text-xs resize-y'}
                    placeholder={"AUTHOR CONTRACT\n\nDate: {{date}}\n\nClient: {{rights_holder}}\nContractor: {{party}}\nProject: {{show}}\n\nFee: {{advance}} EUR\nDelivery: {{end_date}}\n\n[Pogoji...]\n\nNaročnik: _______________ Datum: _______\nIzvajalec: _______________ Datum: _______"} />
                </div>
                <div className="flex gap-2">
                  <button onClick={async () => {
                    if (!newTemplate.title||!newTemplate.body||!user?.id) return;
                    const { data } = await supabase.from('contract_templates').insert({ user_id:user.id, title:newTemplate.title, type:newTemplate.type, description:newTemplate.description, body:newTemplate.body, is_default:false, created_by:user.name }).select().single();
                    if (data) setContractTemplates(prev=>[...prev,data]);
                    setNewTemplate({title:'',type:'custom',description:'',body:''});
                    setShowNewTemplateForm(false);
                  }} className="bg-brand-cyan text-black px-5 py-2 font-black uppercase italic text-xs border-2 border-black hover:bg-white transition-all">Save Template</button>
                  <button onClick={()=>setShowNewTemplateForm(false)} className="border-2 border-white/20 text-white/40 px-4 py-2 font-black uppercase italic text-xs">Cancel</button>
                </div>
              </div>
            )}

            {/* HahaHub templates */}
            <div className="space-y-2">
              <p className="text-[8px] font-black uppercase italic text-brand-yellow/50 tracking-widest">HahaHub Templates</p>
              {contractTemplates.filter((t:any) => t.is_default).map((tmpl:any) => (
                <div key={tmpl.id} className="border-2 border-white/10 hover:border-brand-yellow/30 px-4 py-3 flex items-center justify-between gap-4 transition-all">
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="material-symbols-outlined text-brand-yellow/40 text-sm">description</span>
                    <div>
                      <p className="font-black uppercase italic text-white text-xs">{tmpl.title}</p>
                      {tmpl.description && <p className="text-white/25 text-[9px] italic">{tmpl.description}</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button onClick={() => { setShowContractForm(true); setActiveTemplate(tmpl); setTemplateParams({ show:myShows[0]?.title||'', show_id:myShows[0]?.id||'', royalty:myShows[0]?.scriptRoyaltyPct||'10', share_b:'', party:'', org:'', territory:'', city:'', performances:'', start_date:'', end_date:'', advance:'0', currency:'EUR', rights_holder:user.name, rights_holder_org:'', rights_holder_address:'', rights_holder_email:user.email||'', licensee_address:'', licensee_email:'', language:'', date:new Date().toISOString().split('T')[0], package:'Script License', governing_law:'', author:myShows[0]?.author||'', ref:Date.now().toString().slice(-6) }); }}
                      className="text-[9px] font-black uppercase italic text-brand-yellow border border-brand-yellow/40 px-3 py-1.5 hover:bg-brand-yellow hover:text-black transition-all">
                      Use →
                    </button>
                    <button onClick={async () => {
                      if (!user?.id) return;
                      const { data } = await supabase.from('contract_templates').insert({ user_id:user.id, title:`${tmpl.title} (copy)`, type:tmpl.type, description:tmpl.description||'', body:tmpl.body, is_default:false, created_by:user.name }).select().single();
                      if (data) setContractTemplates(prev=>[...prev, data]);
                    }} className="text-[9px] font-black uppercase italic text-white/30 border border-white/15 px-2 py-1.5 hover:border-brand-cyan hover:text-brand-cyan transition-all">
                      📋 Copy
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* My templates */}
            {contractTemplates.filter((t:any) => !t.is_default).length > 0 && (
              <div className="space-y-2">
                <p className="text-[8px] font-black uppercase italic text-brand-cyan/50 tracking-widest">My Templates</p>
                {contractTemplates.filter((t:any) => !t.is_default).map((tmpl:any) => (
                  <div key={tmpl.id} className="border-2 border-brand-cyan/20 hover:border-brand-cyan/40 px-4 py-3 flex items-center justify-between gap-4 transition-all">
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="material-symbols-outlined text-brand-cyan/40 text-sm">description</span>
                      <div>
                        <p className="font-black uppercase italic text-white text-xs">{tmpl.title}</p>
                        {tmpl.description && <p className="text-white/25 text-[9px] italic">{tmpl.description}</p>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <button onClick={() => { setShowContractForm(true); setActiveTemplate(tmpl); setTemplateParams({ show:myShows[0]?.title||'', show_id:myShows[0]?.id||'', royalty:myShows[0]?.scriptRoyaltyPct||'10', share_b:'', party:'', org:'', territory:'', city:'', performances:'', start_date:'', end_date:'', advance:'0', currency:'EUR', rights_holder:user.name, rights_holder_org:'', rights_holder_address:'', rights_holder_email:user.email||'', licensee_address:'', licensee_email:'', language:'', date:new Date().toISOString().split('T')[0], package:'Script License', governing_law:'', author:myShows[0]?.author||'', ref:Date.now().toString().slice(-6) }); }}
                        className="text-[9px] font-black uppercase italic text-brand-cyan border border-brand-cyan/40 px-3 py-1.5 hover:bg-brand-cyan hover:text-black transition-all">
                        Use →
                      </button>
                      <button onClick={async () => { await supabase.from('contract_templates').delete().eq('id',tmpl.id); setContractTemplates(prev=>prev.filter(t=>t.id!==tmpl.id)); }}
                        className="text-white/20 hover:text-brand-pink transition-colors">
                        <span className="material-symbols-outlined text-sm">delete</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      )}

      {/* ── CALCULATOR ── */}
      {tab === 'calculator' && (() => {
        // Per performance calculations
        const revenuePerf = Number(calc.ticketPrice) * Number(calc.seats) * (Number(calc.occupancy) / 100);
        const royaltyPerf = revenuePerf * Number(calc.royaltyPct) / 100;
        const costsPerf = actors / Number(calc.performances || 1) + techs / Number(calc.performances || 1) + other / Number(calc.performances || 1);
        const fixedCosts = Number((calc as any).fixedCosts || 0);
        const netPerf = revenuePerf - royaltyPerf - (costsPerf);
        const breakEven = netPerf > 0 ? Math.ceil(fixedCosts / netPerf) : null;
        const totalNet = net - fixedCosts;

        // Scenarios (pessimistic 60%, realistic calc.occupancy, optimistic 100%)
        const scenario = (occ: number) => {
          const r = Number(calc.ticketPrice) * Number(calc.seats) * (occ / 100) * Number(calc.performances);
          const roy = r * Number(calc.royaltyPct) / 100;
          const c = actors + techs + other + fixedCosts;
          return r - roy - c;
        };

        // Break-even chart — performances 1 to max
        const maxPerf = Math.max(Number(calc.performances), breakEven ? breakEven + 5 : 20, 20);
        const chartPoints = Array.from({ length: Math.min(maxPerf, 30) }, (_, i) => {
          const p = i + 1;
          const r = Number(calc.ticketPrice) * Number(calc.seats) * (Number(calc.occupancy) / 100) * p;
          const roy = r * Number(calc.royaltyPct) / 100;
          const c = (Number(calc.actorFee) * Number(calc.actorCount) + Number(calc.techFee) * Number(calc.techCount) + Number(calc.otherFee) * Number(calc.otherCount)) * p + fixedCosts;
          return { p, net: r - roy - c };
        });
        const maxNet = Math.max(...chartPoints.map(p => Math.abs(p.net)), 1);

        return (
          <div className="space-y-5">
            <div className="border-l-4 border-brand-yellow pl-4">
              <p className="text-white font-black uppercase italic text-sm">Break-Even Calculator</p>
              <p className="text-white/40 text-xs italic mt-1">Enter your production parameters — see break-even point, profit scenarios, and per-performance net. Use before signing a licensing deal.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* REVENUE */}
              <div className="space-y-3 border-4 border-white/10 p-4">
                <p className="text-[9px] font-black uppercase italic text-brand-yellow tracking-widest">Revenue</p>
                <div className="grid grid-cols-2 gap-2">
                  <div><label className={lbl}>Performances</label><input type="number" value={calc.performances} onChange={e => setCalc(p => ({...p, performances: e.target.value}))} className={inp} /></div>
                  <div><label className={lbl}>Ticket Price (€)</label><input type="number" value={calc.ticketPrice} onChange={e => setCalc(p => ({...p, ticketPrice: e.target.value}))} className={inp} /></div>
                  <div><label className={lbl}>Seats</label><input type="number" value={calc.seats} onChange={e => setCalc(p => ({...p, seats: e.target.value}))} className={inp} /></div>
                  <div><label className={lbl}>Occupancy (%)</label><input type="number" value={calc.occupancy} onChange={e => setCalc(p => ({...p, occupancy: e.target.value}))} className={inp} /></div>
                  <div className="col-span-2"><label className={lbl}>Royalty / Author Fee (%)</label><input type="number" value={calc.royaltyPct} onChange={e => setCalc(p => ({...p, royaltyPct: e.target.value}))} className={inp} /></div>
                </div>
              </div>

              {/* VARIABLE COSTS */}
              <div className="space-y-3 border-4 border-white/10 p-4">
                <p className="text-[9px] font-black uppercase italic text-brand-pink tracking-widest">Variable Costs (per perf.)</p>
                <div className="grid grid-cols-2 gap-2">
                  <div><label className={lbl}>Actor Fee (€)</label><input type="number" value={calc.actorFee} onChange={e => setCalc(p => ({...p, actorFee: e.target.value}))} className={inp} /></div>
                  <div><label className={lbl}>No. of Actors</label><input type="number" value={calc.actorCount} onChange={e => setCalc(p => ({...p, actorCount: e.target.value}))} className={inp} /></div>
                  <div><label className={lbl}>Tech Fee (€)</label><input type="number" value={calc.techFee} onChange={e => setCalc(p => ({...p, techFee: e.target.value}))} className={inp} /></div>
                  <div><label className={lbl}>No. of Techs</label><input type="number" value={calc.techCount} onChange={e => setCalc(p => ({...p, techCount: e.target.value}))} className={inp} /></div>
                  <div><label className={lbl}>Other Staff (€)</label><input type="number" value={calc.otherFee} onChange={e => setCalc(p => ({...p, otherFee: e.target.value}))} className={inp} /></div>
                  <div><label className={lbl}>No. of Other</label><input type="number" value={calc.otherCount} onChange={e => setCalc(p => ({...p, otherCount: e.target.value}))} className={inp} /></div>
                </div>
              </div>

              {/* FIXED COSTS */}
              <div className="space-y-3 border-4 border-brand-cyan/20 p-4">
                <p className="text-[9px] font-black uppercase italic text-brand-cyan tracking-widest">Fixed Costs (one-time)</p>
                <p className="text-white/30 text-[9px] italic">Set, costumes, marketing, rights advance fee — paid once regardless of performances.</p>
                <div>
                  <label className={lbl}>Fixed Costs (€)</label>
                  <input type="number" value={(calc as any).fixedCosts || ''} placeholder="e.g. 15000"
                    onChange={e => setCalc(p => ({...p, fixedCosts: e.target.value} as any))} className={inp} />
                </div>
                {fixedCosts > 0 && breakEven && (
                  <div className="border-2 border-brand-cyan/30 p-3 bg-brand-cyan/5">
                    <p className="text-[8px] font-black uppercase italic text-brand-cyan mb-1">Break-Even Point</p>
                    <p className="text-2xl font-black text-brand-cyan">{breakEven} perfs</p>
                    <p className="text-[9px] text-white/30 italic">to cover fixed costs</p>
                  </div>
                )}
                {fixedCosts > 0 && !breakEven && (
                  <div className="border-2 border-red-500/30 p-3 bg-red-500/5">
                    <p className="text-[8px] font-black uppercase italic text-red-400 mb-1">⚠ Break-Even</p>
                    <p className="text-sm font-black text-red-400">Never — per-perf loss</p>
                  </div>
                )}
              </div>
            </div>

            {/* RESULTS */}
            <div className="border-4 border-brand-yellow p-4 grid grid-cols-2 md:grid-cols-6 gap-3">
              {[
                { label: 'Gross Revenue', value: '€' + Math.round(gross).toLocaleString(), color: 'text-white' },
                { label: 'Royalty / Author', value: '€' + Math.round(royalty).toLocaleString(), color: 'text-brand-yellow' },
                { label: 'Variable Costs', value: '€' + Math.round(totalCosts).toLocaleString(), color: 'text-brand-pink' },
                { label: 'Fixed Costs', value: '€' + Math.round(fixedCosts).toLocaleString(), color: 'text-brand-cyan' },
                { label: 'Net / Performance', value: '€' + Math.round(netPerf).toLocaleString(), color: netPerf >= 0 ? 'text-green-400' : 'text-red-400' },
                { label: 'Total Net', value: '€' + Math.round(totalNet).toLocaleString(), color: totalNet >= 0 ? 'text-green-400' : 'text-red-400' },
              ].map((s, i) => (
                <div key={i} className={"text-center p-2 " + (i === 5 ? (totalNet >= 0 ? 'bg-green-500/10' : 'bg-red-500/10') : '')}>
                  <p className="text-[7px] font-black uppercase italic text-white/30 mb-1">{s.label}</p>
                  <p className={"text-lg font-black " + s.color}>{s.value}</p>
                </div>
              ))}
            </div>

            {/* SCENARIOS */}
            <div className="border-4 border-white/10 p-4">
              <p className="text-[9px] font-black uppercase italic text-white/30 tracking-widest mb-3">Scenarios — Total Net</p>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: '😬 Pessimistic', occ: 60, color: 'border-red-500/40 text-red-400' },
                  { label: '😐 Realistic', occ: Number(calc.occupancy), color: 'border-brand-yellow/40 text-brand-yellow' },
                  { label: '😄 Optimistic', occ: 100, color: 'border-green-500/40 text-green-400' },
                ].map(s => {
                  const v = scenario(s.occ);
                  return (
                    <div key={s.label} className={"border-4 p-4 text-center " + s.color.split(' ')[0]}>
                      <p className="text-[9px] font-black uppercase italic text-white/40 mb-1">{s.label}</p>
                      <p className="text-[9px] text-white/25 mb-2">{s.occ}% occupancy</p>
                      <p className={"text-2xl font-black " + s.color.split(' ')[1]}>€{Math.round(v).toLocaleString()}</p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* BREAK-EVEN CHART */}
            <div className="border-4 border-white/10 p-4">
              <p className="text-[9px] font-black uppercase italic text-white/30 tracking-widest mb-4">
                Cumulative Net by Performance
                {breakEven && <span className="text-brand-cyan ml-2">Break-even at perf #{breakEven}</span>}
              </p>
              <div className="relative h-32">
                {/* Zero line */}
                <div className="absolute w-full border-t border-white/20" style={{ top: '50%' }} />
                <div className="flex items-end gap-0.5 h-full">
                  {chartPoints.map((pt, i) => {
                    const isBreakEven = breakEven && pt.p === breakEven;
                    const pct = pt.net / maxNet;
                    const barH = Math.abs(pct) * 50;
                    return (
                      <div key={i} className="flex-1 flex flex-col items-center justify-center h-full relative group">
                        {pt.net >= 0 ? (
                          <div className="w-full flex flex-col justify-end" style={{ height: '50%' }}>
                            <div className={`w-full transition-all ${isBreakEven ? 'bg-brand-cyan' : 'bg-green-500/60'}`}
                              style={{ height: barH + '%' }} />
                          </div>
                        ) : (
                          <div className="w-full flex flex-col justify-start" style={{ height: '50%', marginTop: '50%' }}>
                            <div className="w-full bg-red-500/60 transition-all" style={{ height: barH + '%' }} />
                          </div>
                        )}
                        {/* Tooltip */}
                        <div className="absolute bottom-full mb-1 hidden group-hover:block bg-brand-black border border-white/20 px-2 py-1 text-[8px] font-black text-white whitespace-nowrap z-10">
                          P{pt.p}: €{Math.round(pt.net).toLocaleString()}
                        </div>
                        {(pt.p % 5 === 0 || pt.p === 1) && (
                          <p className="absolute bottom-0 text-[6px] text-white/20 font-black" style={{ bottom: '-14px' }}>{pt.p}</p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
              <p className="text-[8px] text-white/20 italic mt-5 text-center">Number of performances → hover for value</p>
            </div>

          </div>
        );
      })()}


      {/* ── CONTACTS ── */}
      {tab === 'contacts' && (
        <div className="space-y-5">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <p className="text-white font-black uppercase italic">HAHAfriends</p>
              <p className="text-white/30 text-xs italic mt-0.5">{contacts.length} friends · saved in cloud</p>
            </div>
            <button onClick={() => setShowContactForm(!showContactForm)}
              className="bg-brand-cyan text-black px-4 py-2 font-black uppercase italic text-xs border-2 border-black hover:bg-white transition-all">
              + Add Friend
            </button>
          </div>

          {showContactForm && (
            <div className="border-4 border-brand-cyan/30 p-4 space-y-4">
              <p className="text-[9px] font-black uppercase italic text-brand-cyan tracking-widest">New HAHAfriend</p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                <div><label className={lbl}>Name *</label><input value={newContact.name} onChange={e => setNewContact(p => ({...p, name: e.target.value}))} className={inp} placeholder="Full name" /></div>
                <div><label className={lbl}>Role</label><input placeholder="Director / Agent / Tech..." value={newContact.role} onChange={e => setNewContact(p => ({...p, role: e.target.value}))} className={inp} /></div>
                <div><label className={lbl}>Organisation / Theatre</label><input value={newContact.org} onChange={e => setNewContact(p => ({...p, org: e.target.value}))} className={inp} /></div>
                <div><label className={lbl}>Email</label><input type="email" value={newContact.email} onChange={e => setNewContact(p => ({...p, email: e.target.value}))} className={inp} /></div>
                <div><label className={lbl}>Phone</label><input type="tel" value={newContact.phone} onChange={e => setNewContact(p => ({...p, phone: e.target.value}))} className={inp} /></div>
                <div><label className={lbl}>Country</label><input value={(newContact as any).country || ''} onChange={e => setNewContact(p => ({...p, country: e.target.value} as any))} className={inp} placeholder="e.g. Slovenia" /></div>
                <div className="col-span-2 md:col-span-3"><label className={lbl}>Notes (private)</label><input value={newContact.notes} onChange={e => setNewContact(p => ({...p, notes: e.target.value}))} className={inp} placeholder="How you met, what they're interested in..." /></div>
              </div>
              <div className="flex gap-3">
                <button onClick={async () => {
                  if (!newContact.name || !user?.id) return;
                  const { data } = await supabase.from('hahafriends').insert({
                    user_id: user.id,
                    name: newContact.name,
                    email: newContact.email || null,
                    plan: null,
                    notes: [newContact.role, newContact.org, (newContact as any).country, newContact.phone, newContact.notes].filter(Boolean).join(' · ') || null,
                    source: 'manual',
                  }).select().single();
                  if (data) setContacts(prev => [data, ...prev]);
                  setNewContact({ name: '', role: '', email: '', phone: '', org: '', notes: '' });
                  setShowContactForm(false);
                }} className="bg-brand-cyan text-black px-6 py-2 font-black uppercase italic text-xs border-2 border-black">Save to Cloud</button>
                <button onClick={() => setShowContactForm(false)} className="border-2 border-white/20 text-white/40 px-4 py-2 font-black uppercase italic text-xs">Cancel</button>
              </div>
            </div>
          )}

          {contactsLoading ? (
            <p className="text-white/20 italic text-sm">Loading...</p>
          ) : contacts.length === 0 ? (
            <div className="py-12 text-center space-y-3">
              <p className="text-4xl">🤝</p>
              <p className="text-white/20 font-black uppercase italic text-sm">No HAHAfriends yet.</p>
              <p className="text-white/10 text-xs italic">Add contacts manually or click "Add to HAHAfriends" on any producer profile.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {contacts.map((c: any) => (
                <div key={c.id} className="border-4 border-white/10 px-5 py-4 flex items-center justify-between gap-4 hover:border-brand-cyan/40 transition-all group">
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="w-10 h-10 bg-brand-cyan/15 border-2 border-brand-cyan/30 flex items-center justify-center flex-shrink-0">
                      <span className="font-black text-brand-cyan text-sm">{c.name[0]}</span>
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-black uppercase italic text-white">{c.name}</p>
                        {c.plan && <span className={"text-[7px] font-black uppercase px-1.5 py-0.5 " + (c.plan === 'roar' ? 'bg-brand-pink/20 text-brand-pink' : c.plan === 'laff' ? 'bg-brand-cyan/20 text-brand-cyan' : 'bg-white/10 text-white/30')}>{c.plan?.toUpperCase()}</span>}
                        {c.source && c.source !== 'manual' && <span className="text-[7px] font-black uppercase bg-brand-yellow/10 text-brand-yellow/60 px-1.5 py-0.5">{c.source}</span>}
                      </div>
                      {c.notes && <p className="text-white/30 text-xs mt-0.5">{c.notes}</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                    {c.email && (
                      <a href={`mailto:${c.email}`}
                        className="text-brand-cyan text-[9px] font-black uppercase italic hover:underline hidden group-hover:block">
                        {c.email}
                      </a>
                    )}
                    {c.friend_user_id && (
                      <button onClick={() => {/* navigate to profile */}}
                        className="text-[8px] font-black uppercase italic text-white/30 border border-white/15 px-2 py-0.5 hover:border-brand-cyan hover:text-brand-cyan transition-all">
                        View Profile →
                      </button>
                    )}
                    <button onClick={async () => {
                      await supabase.from('hahafriends').delete().eq('id', c.id);
                      setContacts(prev => prev.filter(x => x.id !== c.id));
                    }} className="text-white/20 hover:text-brand-pink transition-colors opacity-0 group-hover:opacity-100">
                      <span className="material-symbols-outlined text-sm">delete</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── SHOW LOG ── */}
      {tab === 'log' && (
        <div className="space-y-6">
          <div className="border-l-4 border-white/30 pl-4">
            <p className="text-white font-black uppercase italic text-sm">Show Log</p>
            <p className="text-white/50 text-sm italic mt-1">A timeline of all activities across your shows — performances, contracts signed, royalties received. Your complete production history in one place.</p>
          </div>
          <div className="border-4 border-white/10 p-4 space-y-4">
            <p className="text-[9px] font-black uppercase italic text-white/30 tracking-widest">Log a Performance</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div><label className={lbl}>Date</label><input type="date" value={newLog.date} onChange={e => setNewLog(p => ({...p, date: e.target.value}))} className={inp} /></div>
              <div><label className={lbl}>Show</label>
                <select value={newLog.show} onChange={e => setNewLog(p => ({...p, show: e.target.value}))} className={inp}>
                  <option value="">Select...</option>
                  {myShows.map((s: any) => <option key={s.id} value={s.title}>{s.title}</option>)}
                </select>
              </div>
              <div><label className={lbl}>Venue</label><input value={newLog.venue} onChange={e => setNewLog(p => ({...p, venue: e.target.value}))} className={inp} /></div>
              <div><label className={lbl}>Attendance</label><input type="number" value={newLog.attendance} onChange={e => setNewLog(p => ({...p, attendance: e.target.value}))} className={inp} /></div>
              <div className="col-span-2 md:col-span-4"><label className={lbl}>Notes</label><textarea rows={2} value={newLog.notes} onChange={e => setNewLog(p => ({...p, notes: e.target.value}))} placeholder="How did it go? Technical issues, audience reaction, notes for next time..." className={inp + ' resize-none'} /></div>
            </div>
            <button onClick={() => {
              if (!newLog.date || !newLog.show) return;
              setLogs(prev => [{ ...newLog, id: Date.now().toString() }, ...prev]);
              setNewLog({ date: new Date().toISOString().split('T')[0], show: '', venue: '', attendance: '', notes: '' });
            }} className="bg-brand-yellow text-black px-6 py-2 font-black uppercase italic text-xs border-2 border-black hover:bg-white transition-all">
              + Add Log Entry
            </button>
          </div>

          {logs.length === 0 ? (
            <p className="text-white/20 italic text-sm">No performance logs yet.</p>
          ) : (
            <div className="space-y-3">
              {logs.map((l, i) => (
                <div key={l.id || i} className="border-2 border-white/10 p-4 hover:border-brand-cyan transition-all">
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <div className="flex items-center gap-3">
                      <span className="text-brand-yellow font-black text-sm">{new Date(l.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                      <span className="text-white font-black italic text-sm">{l.show}</span>
                      {l.venue && <span className="text-white/40 text-xs italic">{l.venue}</span>}
                      {l.attendance && <span className="text-brand-cyan text-xs font-black">{Number(l.attendance).toLocaleString()} pax</span>}
                    </div>
                    <button onClick={() => setLogs(prev => prev.filter((_, j) => j !== i))} className="text-white/20 hover:text-brand-pink transition-colors flex-shrink-0">
                      <span className="material-symbols-outlined text-sm">delete</span>
                    </button>
                  </div>
                  {l.notes && <p className="text-white/40 text-sm italic border-l-2 border-white/10 pl-3">{l.notes}</p>}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </section>
  );
};

export default ProducerStudio;
