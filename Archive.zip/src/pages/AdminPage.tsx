import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Page, User, Show } from '../types';

interface Invitation {
  id: string;
  recipient: string;
  email: string;
  duration: string;
  status: string;
  generatedUsername: string;
  generatedPassword: string;
  plan?: string;
  created_at?: string;
}

type InvitationDuration = '7 Days' | '1 Month' | '1 Year' | 'Lifetime';
const durations: InvitationDuration[] = ['7 Days', '1 Month', '1 Year', 'Lifetime'];

interface AdminPageProps {
  onNavigate: (page: Page) => void;
  onLogout?: () => void;
  shows: Show[];
  onDeleteShow: (id: string) => void;
  user?: User;
}

// Auto password generator: FirstName + EmailPrefix + 2 digits
// e.g. Jure Bacinhos -> JureBacinhos42
function generatePassword(name: string, email: string): string {
  const firstName = name.trim().split(' ')[0] || 'User';
  const emailPrefix = email.split('@')[0] || 'hub';
  const capitalize = (s: string) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
  const digits = String(Math.floor(Math.random() * 90) + 10);
  return capitalize(firstName) + capitalize(emailPrefix) + digits;
}

// Normalize email before writing to / reading from the invitations table.
// Prevents the "registered but still shows pending" sync bug caused by
// case/whitespace mismatches between invitations.email and auth.users.email.
function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

const AdminPage: React.FC<AdminPageProps> = ({ onNavigate, onLogout, shows, onDeleteShow }) => {
  const [activeTab, setActiveTab] = useState<'analytics' | 'access' | 'catalog' | 'inquiries' | 'errors'>('analytics');
  const [inquiries, setInquiries] = useState<any[]>([]);
  const [errorLogs, setErrorLogs] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [invites, setInvites] = useState<Invitation[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newNote, setNewNote] = useState('');
  const [password, setPassword] = useState('');
  const [selectedDuration, setSelectedDuration] = useState<InvitationDuration>('1 Month');
  const [invitePlan, setInvitePlan] = useState<'gigl' | 'laff' | 'roar'>('laff');
  const [mailLog, setMailLog] = useState<{ title: string; msg: string } | null>(null);
  const [sending, setSending] = useState(false);
  const [inviteSearch, setInviteSearch] = useState('');

  useEffect(() => {
    loadUsers();
    loadInvites();
  }, []);

  // Auto-generate password when name or email changes
  useEffect(() => {
    if (activeTab === 'inquiries') {
      supabase.from('inquiries').select('*').order('created_at', { ascending: false }).limit(200)
        .then(({ data }) => { if (data) setInquiries(data); });
    }
    if (activeTab === 'errors') {
      supabase.from('error_logs').select('*').order('created_at', { ascending: false }).limit(200)
        .then(({ data }) => { if (data) setErrorLogs(data); });
    }
  }, [activeTab]);

  useEffect(() => {
    if (newName && newEmail) {
      setPassword(generatePassword(newName, newEmail));
    }
  }, [newName, newEmail]);

  const loadUsers = async () => {
    setLoadingUsers(true);
    const { data } = await supabase.from('profiles').select('id, name, email, is_paid, is_verified, is_founding, uploaded_show_ids, subscription_expiry, user_type').order('created_at', { ascending: false });
    setUsers(data || []);
    setLoadingUsers(false);
  };

  const loadInvites = async () => {
    const { data } = await supabase.from('invitations').select('*').order('created_at', { ascending: false });
    if (data) setInvites(data.map((inv: any) => ({
      id: inv.id,
      recipient: inv.recipient || inv.name || inv.generated_username?.split('_PRO_')[0]?.replace(/_/g, ' ') || inv.email,
      email: inv.email || inv.generated_username,
      duration: inv.duration || '1 Year',
      status: inv.status,
      generatedUsername: inv.email || inv.generated_username,
      generatedPassword: inv.password || inv.generated_password || '—',
      plan: inv.plan || 'laff',
      created_at: inv.created_at,
      type: inv.type || 'access',
    })));
  };

  const triggerMailLog = (title: string, msg: string) => {
    setMailLog({ title, msg });
    setTimeout(() => setMailLog(null), 8000);
  };

  const sendInvite = async () => {
    if (!newName || !newEmail || !password) return;
    setSending(true);
    const cleanEmail = normalizeEmail(newEmail);

    // Save to invitations table
    const { data } = await supabase.from('invitations').insert([{
      recipient: newName, email: cleanEmail, duration: selectedDuration,
      status: 'pending', password, note: newNote, plan: invitePlan,
    }]).select();

    if (data?.[0]) {
      setInvites(prev => [{
        id: data[0].id, recipient: newName, email: cleanEmail,
        duration: selectedDuration, status: 'pending',
        generatedUsername: cleanEmail, generatedPassword: password,
        plan: invitePlan, created_at: data[0].created_at,
      }, ...prev]);
    }

    try {
      await fetch("https://jnilgukmyfukazwduuig.supabase.co/functions/v1/send-invite", {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail, name: newName, password, note: newNote, duration: selectedDuration, plan: invitePlan })
      });
      triggerMailLog(`Email Sent to ${newName}`, `Dispatched to: ${cleanEmail}\nPassword: ${password}\nPlan: ${invitePlan.toUpperCase()}\nDuration: ${selectedDuration}`);
    } catch (e) { console.error(e); }

    setNewName(''); setNewEmail(''); setNewNote(''); setPassword('');
    setSending(false);
  };

  const deleteInvite = async (id: string, name: string) => {
    if (!window.confirm(`Delete invite for ${name}?`)) return;
    const { error } = await supabase.from('invitations').delete().eq('id', id);
    if (error) { alert('Error deleting: ' + error.message); return; }
    setInvites(prev => prev.filter(i => i.id !== id));
  };

  const deleteUser = async (id: string, name: string) => {
    if (!window.confirm(`Delete ${name}? Cannot be undone.`)) return;
    await supabase.from('profiles').delete().eq('id', id);
    setUsers(prev => prev.filter(u => u.id !== id));
  };

  const setPlan = async (userId: string, plan: string) => {
    const isPaid = plan !== 'gigl';
    const expiryStr = isPaid ? new Date(Date.now() + 365*24*60*60*1000).toISOString().split('T')[0] : null;
    await supabase.from('profiles').update({ user_type: plan, is_paid: isPaid, subscription_expiry: expiryStr }).eq('id', userId);
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, user_type: plan, is_paid: isPaid, subscription_expiry: expiryStr } : u));
    const u = users.find(x => x.id === userId);
    if (u?.email && isPaid) {
      try {
        await fetch("https://jnilgukmyfukazwduuig.supabase.co/functions/v1/send-invite", {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: u.email, name: u.name,
            note: `Your HahaHub membership has been upgraded to ${plan.toUpperCase()}. Log in to access your new features. Break a Laffing Leg. 🦵`,
            duration: '1 Year', plan,
          })
        });
        triggerMailLog(`Upgrade sent to ${u.name}`, `${u.email} upgraded to ${plan.toUpperCase()}`);
      } catch(e) { console.error(e); }
    }
  };

  const toggleVerified = async (id: string, current: boolean) => {
    await supabase.from('profiles').update({ is_verified: !current }).eq('id', id);
    setUsers(prev => prev.map(u => u.id === id ? { ...u, is_verified: !current } : u));
  };

  const toggleFounding = async (id: string, current: boolean) => {
    await supabase.from('profiles').update({ is_founding: !current }).eq('id', id);
    setUsers(prev => prev.map(u => u.id === id ? { ...u, is_founding: !current } : u));
  };

  // Filtered + sorted invites
  const filteredInvites = invites
    .filter(inv =>
      ((inv as any).type || 'access') !== 'founding' && (
      inv.recipient?.toLowerCase().includes(inviteSearch.toLowerCase()) ||
      inv.email?.toLowerCase().includes(inviteSearch.toLowerCase()))
    )
    .sort((a, b) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime());

  return (
    <div className="flex flex-col min-h-screen bg-brand-black text-white">

      {/* TOP NAV */}
      <div className="border-b-4 border-white bg-brand-black sticky top-0 z-50">
        <div className="px-4 py-3 flex items-center justify-between">
          <div>
            <div className="logo-text text-2xl flex leading-none">
              <span className="text-brand-yellow">HAHA</span><span className="text-brand-cyan">HUB</span>
            </div>
            <p className="text-brand-pink text-[8px] font-black tracking-[0.2em] uppercase italic">Control Center</p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => onNavigate('discovery')} className="text-white/40 hover:text-white transition-colors text-xs font-black uppercase italic">← Catalog</button>
            {onLogout && <button onClick={onLogout} className="text-brand-pink/60 hover:text-brand-pink transition-colors"><span className="material-symbols-outlined text-sm">power_settings_new</span></button>}
          </div>
        </div>
        <nav className="flex border-t-2 border-white/10 overflow-x-auto">
          {([
            { key: 'analytics', label: 'Producers', icon: 'group' },
            { key: 'access', label: 'Invites', icon: 'mail' },
            { key: 'catalog', label: 'Archive', icon: 'gavel' },
            { key: 'inquiries', label: 'Inquiries', icon: 'inbox' },
            { key: 'errors', label: 'Errors', icon: 'bug_report' },
          ] as const).map(tab => (
            <button key={tab.key} onClick={() => { setActiveTab(tab.key); if (tab.key === 'analytics') loadUsers(); }}
              className={`flex items-center gap-2 px-5 py-3 border-r-2 border-white/10 transition-all flex-shrink-0 text-[10px] font-black uppercase tracking-widest italic
                ${activeTab === tab.key ? tab.key === 'analytics' ? 'bg-brand-cyan text-black' : tab.key === 'access' ? 'bg-brand-yellow text-black' : tab.key === 'inquiries' ? 'bg-brand-cyan text-black' : 'bg-brand-pink text-white' : 'text-white/40 hover:text-white'}`}>
              <span className="material-symbols-outlined text-sm">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* MAIL LOG */}
      {mailLog && (
        <div className="fixed top-20 right-4 z-[100] bg-brand-black border-4 border-brand-yellow p-6 shadow-neo-magenta w-80 animate-in slide-in-from-right-10">
          <div className="flex items-center justify-between mb-3">
            <span className="text-brand-yellow text-xs font-black uppercase italic">{mailLog.title}</span>
            <button onClick={() => setMailLog(null)}><span className="material-symbols-outlined text-sm text-white/40">close</span></button>
          </div>
          <p className="text-[10px] font-mono text-white/70 whitespace-pre-wrap">{mailLog.msg}</p>
        </div>
      )}

      <main className="flex-1 p-4 md:p-8">

        {/* HEADER */}
        <div className="mb-8">
          <h1 className="text-5xl md:text-7xl font-black uppercase italic tracking-tighter leading-none text-white">
            {activeTab === 'analytics' ? 'PRODUCERS' : activeTab === 'access' ? 'INVITES' : 'ARCHIVE'}
          </h1>
          <div className="h-2 w-32 bg-brand-pink mt-2"></div>
        </div>

        {/* PRODUCERS TAB */}
        {activeTab === 'analytics' && (
          <div className="space-y-3">
            {loadingUsers ? (
              <p className="text-brand-yellow font-black uppercase italic animate-pulse">Loading...</p>
            ) : users.length === 0 ? (
              <p className="text-white/20 font-black uppercase italic">No producers yet.</p>
            ) : users.map((u: any) => {
              const isExpired = u.subscription_expiry &&
                !u.is_founding &&
                u.user_type !== 'roar' &&
                new Date(u.subscription_expiry + 'T23:59:59') < new Date();
              return (
                <div key={u.id} className={`border-4 p-4 transition-all ${isExpired ? 'border-red-500/30 opacity-60' : 'border-white/20 hover:border-brand-yellow'}`}>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="min-w-0 flex-1">
                      <p className="font-black uppercase italic text-white truncate">{u.name || '—'}</p>
                      <p className="text-white/30 text-xs italic truncate">{u.email}</p>
                      <div className="flex gap-3 mt-1 flex-wrap">
                        <span className="text-white/20 text-[9px]">{u.uploaded_show_ids?.length || 0} shows</span>
                        {u.is_founding ? (
                          <span className="text-[9px] text-brand-yellow font-black uppercase italic">⭐ Founding — Lifetime</span>
                        ) : u.subscription_expiry ? (
                          <span className={`text-[9px] font-black uppercase italic px-2 py-0.5 border ${isExpired ? 'text-brand-pink border-brand-pink/30 bg-brand-pink/10' : 'text-brand-cyan border-brand-cyan/20'}`}>
                            {isExpired ? '⚠ EXPIRED' : `Valid until ${u.subscription_expiry}`}
                          </span>
                        ) : (
                          <span className="text-[9px] text-white/20 italic">No expiry set</span>
                        )}
                      </div>
                    </div>
                    <span className={`flex-shrink-0 px-2 py-1 text-[9px] font-black uppercase border ${u.user_type === 'roar' ? 'text-brand-pink border-brand-pink/40' : u.user_type === 'laff' || u.is_paid ? 'text-green-400 border-green-500/30' : 'text-white/30 border-white/10'}`}>
                      {u.user_type === 'roar' ? 'ROAR' : u.user_type === 'laff' || u.is_paid ? 'LAFF' : 'GIGL'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <select value={u.user_type || (u.is_paid ? 'laff' : 'gigl')} onChange={e => setPlan(u.id, e.target.value)}
                      className="px-3 py-2 text-[10px] font-black uppercase italic border-2 border-white/20 bg-brand-black text-white hover:border-brand-yellow cursor-pointer">
                      <option value="gigl">GIGL — Free</option>
                      <option value="laff">LAFF — €99</option>
                      <option value="roar">ROAR — €189</option>
                    </select>
                    <button onClick={() => toggleVerified(u.id, u.is_verified)}
                      className={`px-3 py-2 text-[10px] font-black uppercase italic border-2 transition-all flex items-center gap-1 ${u.is_verified ? 'bg-brand-cyan border-brand-cyan text-black' : 'border-white/20 text-white/30 hover:border-brand-cyan'}`}>
                      <span className="material-symbols-outlined text-sm">check</span>
                      {u.is_verified ? 'Verified' : 'Verify'}
                    </button>
                    <button onClick={() => toggleFounding(u.id, u.is_founding)}
                      className={`px-3 py-2 text-[10px] font-black uppercase italic border-2 transition-all flex items-center gap-1 ${u.is_founding ? 'bg-brand-yellow border-brand-yellow text-black' : 'border-white/20 text-white/30 hover:border-brand-yellow'}`}>
                      <span className="material-symbols-outlined text-sm">star</span>
                      {u.is_founding ? 'Founding' : 'Found.'}
                    </button>
                    <button onClick={async () => {
                      const newExpiry = new Date(Date.now() + 365*24*60*60*1000).toISOString().split('T')[0];
                      await supabase.from('profiles').update({ subscription_expiry: newExpiry, is_paid: true }).eq('id', u.id);
                      setUsers(prev => prev.map(x => x.id === u.id ? { ...x, subscription_expiry: newExpiry, is_paid: true } : x));
                      if (u.email) {
                        try {
                          await fetch("https://jnilgukmyfukazwduuig.supabase.co/functions/v1/send-invite", {
                            method: 'POST', headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                              email: u.email, name: u.name || u.email,
                              note: u.name + ". Your HahaHub membership has been extended for 1 year. Valid until " + newExpiry + ".\n\nBreak a Laffing Leg. 🦵\nhahahub.art",
                              duration: '1 Year', plan: u.user_type || 'laff',
                            })
                          });
                        } catch(e) { console.error(e); }
                      }
                      triggerMailLog('Extended ' + (u.name || u.email), 'Account extended until ' + newExpiry + '. Email sent.');
                    }} className="px-3 py-2 text-[10px] font-black uppercase italic border-2 border-brand-cyan/30 text-brand-cyan hover:bg-brand-cyan hover:text-black transition-all flex items-center gap-1">
                      <span className="material-symbols-outlined text-sm">update</span>
                      +1 Year
                    </button>
                    <button onClick={async () => {
                      if (!u.email) return;
                      const { error } = await supabase.auth.resetPasswordForEmail(u.email, { redirectTo: 'https://www.hahahub.art/login' });
                      if (!error) triggerMailLog('Reset sent to ' + (u.name || u.email), 'Password reset link sent to ' + u.email);
                      else triggerMailLog('Error', error.message);
                    }} className="px-3 py-2 text-[10px] font-black uppercase italic border-2 border-brand-yellow/30 text-brand-yellow hover:bg-brand-yellow hover:text-black transition-all flex items-center gap-1">
                      <span className="material-symbols-outlined text-sm">lock_reset</span>
                      Reset PW
                    </button>
                    <button onClick={() => deleteUser(u.id, u.name || u.email)}
                      className="px-3 py-2 text-[10px] font-black uppercase italic border-2 border-red-500/30 text-red-400 hover:bg-red-500 hover:text-white transition-all flex items-center gap-1 ml-auto">
                      <span className="material-symbols-outlined text-sm">delete</span>
                      Delete
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* INVITES TAB */}
        {activeTab === 'access' && (
          <div className="space-y-8">

            {/* SEND INVITE FORM */}
            <div className="border-4 border-brand-yellow p-6 space-y-4 shadow-neo-yellow">
              <p className="text-brand-yellow text-[10px] font-black uppercase italic tracking-widest">New Invite →</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <input type="text" placeholder="Producer Name" value={newName} onChange={e => setNewName(e.target.value)}
                  className="bg-brand-black border-2 border-white/20 focus:border-brand-yellow text-white font-bold italic p-3 outline-none text-sm" />
                <input type="email" placeholder="Email" value={newEmail} onChange={e => setNewEmail(e.target.value)}
                  className="bg-brand-black border-2 border-white/20 focus:border-brand-yellow text-white font-bold italic p-3 outline-none text-sm" />
              </div>
              {/* Auto password — editable */}
              <div>
                <p className="text-[9px] font-black uppercase italic text-white/40 mb-1">Temp Password <span className="text-brand-cyan">(auto-generated, editable)</span></p>
                <input type="text" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)}
                  className="w-full bg-brand-black border-2 border-brand-cyan/40 focus:border-brand-cyan text-brand-cyan font-mono font-bold p-3 outline-none text-sm" />
              </div>
              <div className="relative">
                <textarea placeholder="Personal invite note..." value={newNote} onChange={e => setNewNote(e.target.value)} rows={4}
                  className="w-full bg-brand-black border-2 border-white/20 focus:border-brand-yellow text-white font-bold italic p-3 outline-none text-sm resize-none" />
                <button type="button"
                  onClick={() => {
                    const lines = [
                      'Hey ' + (newName || '[Name]') + '! 🥊',
                      '',
                      "You're invited to join the HahaHub Crew — the first P2P comedy rights marketplace.",
                      '',
                      'Your login credentials:',
                      'Email: ' + (newEmail || '[email]'),
                      'Password: ' + (password || '[password]'),
                      '',
                      'Change your password after first login: My Hub → My Profile.',
                      '',
                      'Welcome to the HahaHub Crew. Break a Laffing Leg. 🦵',
                      '— The HahaHub Team',
                    ];
                    setNewNote(lines.join('\n'));
                  }}
                  className="absolute bottom-2 right-2 text-[8px] font-black uppercase italic text-brand-yellow border border-brand-yellow/40 px-2 py-1 hover:bg-brand-yellow hover:text-black transition-all">
                  Fill Template
                </button>
              </div>

              {/* Duration */}
              <div>
                <p className="text-[9px] font-black uppercase italic text-white/40 mb-2">Duration</p>
                <div className="flex gap-2 flex-wrap">
                  {durations.map(d => (
                    <button key={d} onClick={() => setSelectedDuration(d)}
                      className={`px-4 py-2 text-[10px] font-black uppercase italic border-2 transition-all ${selectedDuration === d ? 'bg-brand-pink text-white border-brand-pink' : 'border-white/20 text-white/40 hover:border-white'}`}>
                      {d}
                    </button>
                  ))}
                </div>
              </div>

              {/* Plan */}
              <div>
                <p className="text-[9px] font-black uppercase italic text-white/40 mb-2">Plan</p>
                <div className="flex gap-2 flex-wrap">
                  {(['gigl', 'laff', 'roar'] as const).map(plan => (
                    <button key={plan} onClick={() => setInvitePlan(plan)}
                      className={`px-4 py-2 text-[10px] font-black uppercase italic border-2 transition-all ${invitePlan === plan ?
                        plan === 'roar' ? 'bg-brand-pink text-white border-brand-pink' :
                        plan === 'laff' ? 'bg-brand-cyan text-black border-brand-cyan' :
                        'bg-white text-black border-white' : 'border-white/20 text-white/40 hover:border-white'}`}>
                      {plan === 'gigl' ? 'GIGL — Free' : plan === 'laff' ? 'LAFF — €99' : 'ROAR — €189'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 flex-wrap">
              <button onClick={sendInvite} disabled={sending || !newName || !newEmail || !password}
                className="bg-brand-yellow text-black px-8 py-3 font-black uppercase italic border-4 border-black hover:bg-white transition-all disabled:opacity-40 text-sm">
                {sending ? 'Dispatching...' : 'Dispatch Invite →'}
              </button>
              <button onClick={async () => {
                if (!newName || !newEmail) return;
                setSending(true);
                const cleanEmail = normalizeEmail(newEmail);
                const foundingPassword = generatePassword(newName, cleanEmail);
                try {
                  // Save to invitations as founding type
                  const { error: insertError } = await supabase.from('invitations').insert([{
                    recipient: newName, email: cleanEmail, duration: 'lifetime',
                    status: 'pending', password: foundingPassword, note: 'Founding Member Invite', plan: 'roar', type: 'founding'
                  }]);
                  if (insertError) {
                    console.error('Founding invite insert error:', insertError);
                    alert(`❌ Could not save invite for ${newName}: ${insertError.message}\n\nEmail was NOT sent.`);
                    setSending(false);
                    return;
                  }
                  await fetch('/api/send-email', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ type: 'founding_invite', to: cleanEmail, data: { name: newName, email: cleanEmail, password: foundingPassword } })
                  });
                  triggerMailLog(`Founding Invite Sent to ${newName}`, `Dispatched to: ${cleanEmail}\nPassword: ${foundingPassword}`);
                  loadInvites();
                } catch (e) { console.error(e); alert(`❌ Something went wrong sending the invite to ${newName}.`); }
                setSending(false);
              }} disabled={sending || !newName || !newEmail}
                className="bg-brand-pink text-white px-8 py-3 font-black uppercase italic border-4 border-black hover:bg-white hover:text-black transition-all disabled:opacity-40 text-sm">
                {sending ? 'Sending...' : '⭐ Send Founding Invite →'}
              </button>
              </div>
            </div>

            {/* FOUNDING INVITE LIST */}
            {invites.filter((i: any) => ((i as any).type || 'access') === 'founding').length > 0 && (
              <div className="space-y-2 border-4 border-brand-pink/30 p-4">
                <p className="text-[9px] font-black uppercase italic text-brand-pink tracking-widest">⭐ Founding Invites — {invites.filter((i: any) => ((i as any).type || 'access') === 'founding').length} sent</p>
                {invites.filter((i: any) => ((i as any).type || 'access') === 'founding').map((inv: any) => (
                  <div key={inv.id} className="flex items-center justify-between gap-3 border border-white/10 px-3 py-2">
                    <div>
                      <p className="font-black uppercase italic text-white text-xs">{inv.recipient}</p>
                      <p className="text-white/30 text-[9px]">{inv.email}{inv.generatedPassword && inv.generatedPassword !== '—' ? ` · ${inv.generatedPassword}` : ''}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-[8px] font-black uppercase px-2 py-0.5 ${inv.status === 'used' ? 'bg-green-500/20 text-green-400' : 'bg-brand-pink/20 text-brand-pink'}`}>
                        {inv.status === 'used' ? 'Joined ✓' : 'Invited'}
                      </span>
                      {inv.status !== 'used' && (
                        <button onClick={async () => {
                          try {
                            let pw = inv.generatedPassword;
                            if (!pw || pw === '—') {
                              pw = generatePassword(inv.recipient, inv.email);
                              await supabase.from('invitations').update({ password: pw }).eq('id', inv.id);
                              setInvites(prev => prev.map(i => i.id === inv.id ? { ...i, generatedPassword: pw } : i));
                            }
                            const res = await fetch('/api/send-email', {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ type: 'founding_invite', to: inv.email, data: { name: inv.recipient, email: inv.email, password: pw } })
                            });
                            const json = await res.json();
                            if (json.success) {
                              triggerMailLog(`Founding Invite Resent to ${inv.recipient}`, `Dispatched to: ${inv.email}`);
                              alert('✅ Sent to ' + inv.email);
                            } else {
                              alert('❌ Error: ' + JSON.stringify(json));
                            }
                          } catch(e: any) {
                            alert('❌ Failed: ' + e.message);
                          }
                        }} className="text-[8px] font-black uppercase px-2 py-1 border border-brand-pink/40 text-brand-pink hover:bg-brand-pink hover:text-white transition-all flex items-center gap-1">
                          <span className="material-symbols-outlined text-xs">send</span>
                          Resend
                        </button>
                      )}
                      <button onClick={() => deleteInvite(inv.id, inv.recipient)} className="text-[8px] font-black uppercase px-2 py-1 border border-red-500/30 text-red-400 hover:bg-red-500 hover:text-white transition-all flex items-center gap-1">
                        <span className="material-symbols-outlined text-xs">delete</span>
                        Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* INVITE LIST */}
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <p className="text-[9px] font-black uppercase italic text-white/40 tracking-widest">{filteredInvites.filter((i: any) => ((i as any).type || 'access') !== 'founding').length} access invites dispatched</p>
                {/* Search */}
                <input
                  type="text"
                  placeholder="Search name or email..."
                  value={inviteSearch}
                  onChange={e => setInviteSearch(e.target.value)}
                  className="bg-brand-black border-2 border-white/20 focus:border-brand-yellow text-white font-bold italic p-2 outline-none text-xs w-64"
                />
              </div>

              {filteredInvites.length === 0 ? (
                <p className="text-white/20 font-black uppercase italic">No invites found.</p>
              ) : filteredInvites.map(inv => (
                <div key={inv.id} className="border-4 border-white/20 p-4 hover:border-brand-yellow transition-all">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="min-w-0">
                      <p className="font-black uppercase italic text-white">{inv.recipient}</p>
                      <p className="text-white/30 text-xs italic truncate">{inv.email}</p>
                      {inv.created_at && (
                        <p className="text-white/20 text-[9px] mt-1">
                          {new Date(inv.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                        </p>
                      )}
                    </div>
                    <span className={`flex-shrink-0 px-2 py-1 text-[9px] font-black uppercase italic border ${(inv as any).status === 'used' ? 'bg-brand-yellow text-black border-brand-yellow' : 'text-white/40 border-white/20'}`}>
                      {(inv as any).status === 'used' ? '🥊 Tickled' : 'Sent'}
                    </span>
                  </div>
                  <div className="bg-brand-black border border-white/10 p-3 mb-3 font-mono">
                    <p className="text-[10px] text-brand-cyan font-black">Email: {inv.generatedUsername}</p>
                    <p className="text-[10px] text-brand-pink font-black">Pass: {inv.generatedPassword}</p>
                  </div>
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <div className="flex gap-3 flex-wrap">
                      <span className="text-[9px] font-black uppercase text-brand-yellow">{inv.duration}</span>
                      <span className="text-[9px] font-black uppercase text-brand-cyan">{inv.plan?.toUpperCase() || 'LAFF'}</span>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={async () => {
                        try {
                          await fetch("https://jnilgukmyfukazwduuig.supabase.co/functions/v1/send-invite", {
                            method: 'POST', headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ email: inv.email, name: inv.recipient, password: inv.generatedPassword, duration: inv.duration, plan: inv.plan || 'laff', note: 'Resent credentials.' })
                          });
                          triggerMailLog('Resent to ' + inv.recipient, 'Credentials resent to ' + inv.email);
                        } catch(e) { console.error(e); }
                      }} className="px-3 py-1 text-[9px] font-black uppercase italic border-2 border-brand-cyan/30 text-brand-cyan hover:bg-brand-cyan hover:text-black transition-all flex items-center gap-1">
                        <span className="material-symbols-outlined text-sm">send</span>
                        Resend
                      </button>
                      <button onClick={() => deleteInvite(inv.id, inv.recipient)}
                        className="px-3 py-1 text-[9px] font-black uppercase italic border-2 border-red-500/30 text-red-400 hover:bg-red-500 hover:text-white transition-all flex items-center gap-1">
                        <span className="material-symbols-outlined text-sm">delete</span>
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ARCHIVE TAB */}
        {activeTab === 'inquiries' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-black uppercase italic text-brand-cyan">All Inquiries <span className="text-white/30">({inquiries.length})</span></h3>
              <div className="flex gap-4 text-xs font-black uppercase italic text-white/40">
                <span>New: {inquiries.filter(i => i.deal_status === 'new' || !i.deal_status).length}</span>
                <span>Active: {inquiries.filter(i => ['contacted','negotiating','contract_sent'].includes(i.deal_status)).length}</span>
                <span>Signed: {inquiries.filter(i => ['signed','royalties'].includes(i.deal_status)).length}</span>
              </div>
            </div>
            <div className="border-4 border-white/10 overflow-hidden">
              <div className="grid grid-cols-12 bg-white/5 px-4 py-2 text-[8px] font-black uppercase italic text-white/40 border-b border-white/10">
                <span className="col-span-2">Show</span>
                <span className="col-span-2">From</span>
                <span className="col-span-2">Email</span>
                <span className="col-span-2">Package</span>
                <span className="col-span-2">Status</span>
                <span className="col-span-2">Date</span>
              </div>
              {inquiries.map(inq => (
                <div key={inq.id} className="grid grid-cols-12 px-4 py-3 border-b border-white/5 hover:bg-white/3 text-xs">
                  <span className="col-span-2 font-black uppercase italic truncate">{inq.show_title}</span>
                  <span className="col-span-2 font-black italic truncate">{inq.from_name}</span>
                  <span className="col-span-2 text-white/40 truncate">{inq.from_email}</span>
                  <span className="col-span-2">
                    {inq.package_type && <span className={"text-[8px] font-black uppercase px-1.5 py-0.5 " + (inq.package_type === 'full_punch' ? 'bg-brand-pink/20 text-brand-pink' : 'bg-brand-yellow/20 text-brand-yellow')}>{inq.package_type === 'full_punch' ? 'Full Punch' : 'Script'}</span>}
                  </span>
                  <span className="col-span-2">
                    <span className={"text-[8px] font-black uppercase px-1.5 py-0.5 " + (inq.deal_status === 'signed' ? 'bg-green-400/20 text-green-400' : inq.deal_status === 'new' || !inq.deal_status ? 'bg-brand-pink/20 text-brand-pink' : 'bg-brand-yellow/20 text-brand-yellow')}>
                      {inq.deal_status || 'new'}
                    </span>
                  </span>
                  <span className="col-span-2 text-white/40">{new Date(inq.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: '2-digit' })}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'catalog' && (
          <div className="space-y-3">
            {shows.length === 0 ? (
              <p className="text-white/20 font-black uppercase italic">No shows in archive.</p>
            ) : shows.map(show => (
              <div key={show.id} className="border-4 border-white/20 p-4 flex items-center justify-between gap-4 hover:border-brand-pink transition-all">
                <div className="min-w-0">
                  <p className="font-black uppercase italic text-white truncate">{show.title}</p>
                  <p className="text-white/30 text-xs italic">{show.genre} · {show.location} · {show.productionYear}</p>
                  <p className="text-white/20 text-[9px] mt-1">{show.viewsCount} views · {show.inquiriesCount} inquiries</p>
                </div>
                <button onClick={async () => {
                  if (!window.confirm(`Delete "${show.title}"? This cannot be undone.`)) return;
                  // Find show owner
                  const { data: profile } = await supabase.from('profiles').select('name, email').eq('id', (show as any).user_id).maybeSingle();
                  // Try auth.users if profile email is null
                  let ownerEmail = profile?.email;
                  let ownerName = profile?.name || 'Producer';
                  if (!ownerEmail && (show as any).user_id) {
                    const { data: authUser } = await supabase.auth.admin?.getUserById?.((show as any).user_id) || { data: null };
                    ownerEmail = (authUser as any)?.user?.email;
                  }
                  if (ownerEmail) {
                    await fetch('/api/send-email', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        type: 'show_removed',
                        to: ownerEmail,
                        data: { name: ownerName, showTitle: show.title, reason: '' }
                      })
                    });
                  }
                  onDeleteShow(show.id);
                }}
                  className="flex-shrink-0 px-3 py-2 text-[10px] font-black uppercase italic border-2 border-red-500/30 text-red-400 hover:bg-red-500 hover:text-white transition-all flex items-center gap-1">
                  <span className="material-symbols-outlined text-sm">delete</span>
                  Delete
                </button>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'errors' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between mb-4">
              <p className="text-[9px] font-black uppercase italic text-white/30 tracking-widest">
                {errorLogs.length} error{errorLogs.length !== 1 ? 's' : ''} logged
              </p>
              <button onClick={() => supabase.from('error_logs').select('*').order('created_at', { ascending: false }).limit(200).then(({ data }) => { if (data) setErrorLogs(data); })}
                className="text-[9px] font-black uppercase italic text-brand-cyan border border-brand-cyan/30 px-3 py-1 hover:bg-brand-cyan hover:text-black transition-all flex items-center gap-1">
                <span className="material-symbols-outlined text-sm">refresh</span>
                Refresh
              </button>
            </div>
            {errorLogs.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <p className="text-4xl">✅</p>
                <p className="text-white/20 font-black uppercase italic">No errors logged. Clean run.</p>
              </div>
            ) : errorLogs.map(log => (
              <div key={log.id} className="border-2 border-red-500/20 bg-red-500/5 p-4 space-y-2">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="text-[8px] font-black uppercase bg-red-500/20 text-red-400 px-2 py-0.5">{log.action || 'Unknown'}</span>
                      {log.page && <span className="text-[8px] font-black uppercase bg-white/5 text-white/30 px-2 py-0.5">{log.page}</span>}
                    </div>
                    <p className="font-black uppercase italic text-red-300 text-sm truncate">{log.error_message}</p>
                    {log.user_email && <p className="text-white/30 text-[9px] mt-1">{log.user_email}</p>}
                    {log.error_details && (
                      <p className="text-white/20 text-[9px] font-mono mt-1 truncate">{typeof log.error_details === 'string' ? log.error_details : JSON.stringify(log.error_details)}</p>
                    )}
                  </div>
                  <p className="text-white/20 text-[9px] flex-shrink-0">
                    {new Date(log.created_at).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

      </main>
    </div>
  );
};

export default AdminPage;
